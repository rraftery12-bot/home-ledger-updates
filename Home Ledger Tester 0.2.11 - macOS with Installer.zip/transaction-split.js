(() => {
  const style = document.createElement('style');
  style.textContent = '.splitButton{border:1px solid var(--line);background:#fff;color:var(--green);border-radius:7px;padding:7px 9px;font-weight:700;cursor:pointer}.splitButton:hover{background:var(--soft)}.splitModal{position:fixed;inset:0;z-index:100;background:rgba(20,35,29,.48);display:flex;align-items:center;justify-content:center;padding:24px}.splitCard{width:min(1100px,97vw);max-height:90vh;overflow:auto;background:var(--paper);border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.24);padding:24px}.splitHead,.splitFooter{display:flex;align-items:center;justify-content:space-between;gap:16px}.splitRows{display:grid;gap:10px;margin:20px 0}.splitRow{display:grid;grid-template-columns:125px minmax(170px,1fr) minmax(150px,210px) 115px minmax(150px,210px) auto;gap:9px;align-items:center}.splitRow input{width:100%}.splitAmount{text-align:right}.splitBalance.good{color:var(--green)}.splitBalance.bad{color:var(--orange)}@media(max-width:900px){.splitRow{grid-template-columns:1fr 1fr}.splitRow .removeSplit{justify-self:start}}';
  document.head.appendChild(style);
  const modal = document.createElement('div');
  modal.className = 'splitModal hidden';
  modal.innerHTML = '<div class="splitCard"><div class="splitHead"><div><h2>Split transaction</h2><p id="splitOriginal"></p></div><button class="deleteTransaction" id="closeSplit" type="button">Close</button></div><div class="splitRows" id="splitRows"></div><div class="splitFooter"><button class="button" id="addSplitRow" type="button">＋ Add another split</button><div><b id="splitBalance" class="splitBalance"></b><button class="button" id="saveSplit" type="button">Save split</button></div></div></div>';
  document.body.appendChild(modal);
  let target = null, splitOptions = {};
  const optionList = values => '<option value=""></option>' + values.map(value => `<option value="${escapeHtml(value)}">`).join('');
  function splitRow(values = {}) {
    const row = document.createElement('div');
    row.className = 'splitRow';
    row.innerHTML = `<input class="splitDate" placeholder="M/D/YYYY" value="${escapeHtml(displayLedgerDate(values.transactionDate || ''))}"><input class="splitDescription" placeholder="Description" value="${escapeHtml(values.description || '')}"><span><input class="splitCategory" list="splitCategories" placeholder="Category" value="${escapeHtml(values.category || '')}"></span><input class="splitAmount" inputmode="decimal" placeholder="Amount" value="${values.amount ?? ''}"><span><input class="splitAccount" list="splitAccounts" placeholder="${splitOptions.inbox ? 'Account' : 'Account (optional)'}" value="${escapeHtml(values.account || '')}"></span><button class="deleteTransaction removeSplit" type="button">Remove</button>`;
    row.querySelector('.removeSplit').onclick = () => { if (document.querySelectorAll('.splitRow').length > 2) row.remove(); updateBalance(); };
    row.querySelectorAll('input').forEach(input => input.oninput = updateBalance);
    $('#splitRows').appendChild(row);
  }
  function numeric(value) { const number = Number(String(value).replace(/[$,]/g, '')); return Number.isFinite(number) ? number : NaN; }
  function updateBalance() {
    if (!target) return;
    const sum = [...document.querySelectorAll('.splitAmount')].reduce((total, input) => total + (numeric(input.value) || 0), 0);
    const difference = Number(target.amount) - sum;
    const label = $('#splitBalance');
    label.textContent = Math.abs(difference) < .005 ? `Balanced at ${money(sum)}` : `${money(difference)} remaining · `;
    label.className = `splitBalance ${Math.abs(difference) < .005 ? 'good' : 'bad'}`;
    $('#saveSplit').disabled = Math.abs(difference) >= .005;
  }
  function openSplit(transaction, options = {}) {
    if (transaction.isNew) return alert('Save the new transaction before splitting it.');
    target = transaction;
    splitOptions = options;
    $('#splitOriginal').textContent = `${displayLedgerDate(transaction.transactionDate)} · ${transaction.description} · ${money(transaction.amount)}`;
    $('#splitRows').innerHTML = '';
    splitRow({transactionDate: transaction.transactionDate, description: transaction.description, category: transaction.category, amount: Number(transaction.amount).toFixed(2), account: transaction.account});
    splitRow({transactionDate: transaction.transactionDate, description: transaction.description, category: transaction.category, amount: '0.00', account: transaction.account});
    modal.classList.remove('hidden');
    updateBalance();
    setTimeout(() => document.querySelector('.splitRow .splitDescription')?.focus(), 0);
  }
  function closeSplit() { modal.classList.add('hidden'); target = null; }
  $('#closeSplit').onclick = closeSplit;
  modal.onclick = event => { if (event.target === modal) closeSplit(); };
  $('#addSplitRow').onclick = () => { splitRow({transactionDate: target?.transactionDate, description: target?.description, category: target?.category, amount: '0.00', account: target?.account}); updateBalance(); };
  $('#saveSplit').onclick = async () => {
    const rows = [...document.querySelectorAll('.splitRow')].map(row => ({transactionDate: row.querySelector('.splitDate').value.trim(), description: row.querySelector('.splitDescription').value.trim(), category: row.querySelector('.splitCategory').value.trim(), amount: row.querySelector('.splitAmount').value.trim(), account: row.querySelector('.splitAccount').value.trim()}));
    if (rows.some(row => !validReviewDate(row.transactionDate) || !row.description || !boot.categories.includes(row.category) || !Number.isFinite(numeric(row.amount)) || (splitOptions.inbox ? !boot.accounts.some(account => account.name === row.account) : row.account && !boot.accounts.some(account => account.name === row.account)))) return alert(`Every split needs a valid date, description, category, and amount. ${splitOptions.inbox ? 'Choose an account for every line.' : 'Account may be blank or must match an account in this budget.'}`);
    if (!confirm(`Replace this transaction with ${rows.length} split transactions?`)) return;
    try { const result = await api(splitOptions.inbox ? '/api/inbox/split' : '/api/transactions/split', {method:'POST', body:JSON.stringify({id:target.id, rows})}); const done = splitOptions.onComplete; closeSplit(); if (done) await done(); else { await loadLedger(1); await load(boot.month); } alert(`Transaction split into ${result.created} lines.`); }
    catch (error) { alert(error.message); }
  };
  const categories = document.createElement('datalist'); categories.id = 'splitCategories'; categories.innerHTML = optionList(boot.categories); document.body.appendChild(categories);
  const accounts = document.createElement('datalist'); accounts.id = 'splitAccounts'; accounts.innerHTML = optionList(boot.accounts.map(account => account.name)); document.body.appendChild(accounts);
  window.openTransactionSplit = openSplit;
  const previousRender = renderLedger;
  renderLedger = function() {
    previousRender();
    categories.innerHTML = optionList(boot.categories);
    accounts.innerHTML = optionList(boot.accounts.map(account => account.name));
    [...document.querySelectorAll('#ledgerRows tr')].forEach((row, index) => {
      const transaction = ledger.rows[index];
      if (!transaction || row.querySelector('.splitButton')) return;
      const cell = document.createElement('td');
      cell.innerHTML = '<button class="splitButton" type="button" title="Split transaction">Split</button>';
      row.children[0].after(cell);
      cell.querySelector('button').onclick = () => openSplit(transaction);
    });
  };
  const header = document.querySelector('#transactions thead tr');
  if (header && !header.querySelector('.splitHeading')) { const th = document.createElement('th'); th.className = 'splitHeading'; th.textContent = ''; header.children[0].after(th); }
})();
