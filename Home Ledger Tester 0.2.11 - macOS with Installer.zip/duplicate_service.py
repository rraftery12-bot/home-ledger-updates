from datetime import datetime


def record_decision(db, fingerprint, decision, reason, matched_transaction_id=None):
    existing = db.execute(
        "SELECT id FROM duplicate_audit WHERE fingerprint=? AND decision=? AND COALESCE(matched_transaction_id,-1)=COALESCE(?,-1) ORDER BY id DESC LIMIT 1",
        (fingerprint, decision, matched_transaction_id),
    ).fetchone()
    if existing:
        db.execute(
            "UPDATE duplicate_audit SET reason=?,repeat_count=repeat_count+1,last_seen_at=? WHERE id=?",
            (reason, datetime.now().isoformat(timespec="seconds"), existing["id"]),
        )
    else:
        db.execute(
            "INSERT INTO duplicate_audit(fingerprint,decision,reason,matched_transaction_id,last_seen_at) VALUES(?,?,?,?,?)",
            (fingerprint, decision, reason, matched_transaction_id, datetime.now().isoformat(timespec="seconds")),
        )


def hold_for_review(db, fingerprint, transaction_date, posted_date, description, amount, mapping, source_account_id, source, match):
    db.execute(
        "INSERT INTO duplicate_reviews(fingerprint,transaction_date,posted_date,raw_description,amount,account_id,card_last4,source_account_id,source,matched_transaction_id,reason,status,resolved_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'pending',NULL) ON CONFLICT(fingerprint) DO UPDATE SET transaction_date=excluded.transaction_date,posted_date=excluded.posted_date,raw_description=excluded.raw_description,amount=excluded.amount,account_id=excluded.account_id,card_last4=excluded.card_last4,source_account_id=excluded.source_account_id,matched_transaction_id=excluded.matched_transaction_id,reason=excluded.reason,status='pending',resolved_at=NULL",
        (fingerprint, transaction_date, posted_date, description, amount, mapping["ledger_account_id"], mapping.get("mask") or "", source_account_id, source, match["transaction_id"], match["reason"]),
    )
    record_decision(db, fingerprint, "needs_review", match["reason"], match["transaction_id"])


def resolve_review(db, row, keep):
    if keep:
        db.execute(
            "INSERT OR IGNORE INTO inbox_transactions(fingerprint,transaction_date,posted_date,raw_description,amount,account_id,card_last4,source_account_id,source) VALUES(?,?,?,?,?,?,?,?,?)",
            (row["fingerprint"], row["transaction_date"], row["posted_date"], row["raw_description"], row["amount"], row["account_id"], row["card_last4"], row["source_account_id"], row["source"]),
        )
        decision, reason = "sent_to_review", "User determined this was a separate transaction"
    else:
        db.execute("INSERT OR IGNORE INTO ignored_inbox_transactions(fingerprint) VALUES(?)", (row["fingerprint"],))
        if row["matched_transaction_id"]:
            db.execute("UPDATE transactions SET source_fingerprint=? WHERE id=? AND source_fingerprint IS NULL", (row["fingerprint"], row["matched_transaction_id"]))
        decision, reason = "confirmed_duplicate", "User confirmed and linked the suggested legacy match"
    db.execute("UPDATE duplicate_reviews SET status=?,resolved_at=CURRENT_TIMESTAMP WHERE id=?", (decision, row["id"]))
    record_decision(db, row["fingerprint"], decision, reason, row["matched_transaction_id"])
    return decision
