from __future__ import annotations

import calendar
import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import urllib.error
import urllib.request
import uuid
import webbrowser
import zipfile
from difflib import SequenceMatcher
from datetime import datetime, timedelta
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from backup_service import create_complete_daily_backup
from duplicate_rules import legacy_duplicate_candidates
from duplicate_service import hold_for_review, record_decision, resolve_review

# Local Home Ledger server (running-fund transaction drill-down enabled).
ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "home_ledger.sqlite3"
PROFILE_CONFIG_PATH = ROOT / "profiles.json"
PROFILE_DB_DIR = ROOT / "profiles"
ACTIVE_PROFILE_ID = "home-ledger"
SEED_PATH = ROOT / "migration_seed.json"
BACKUP_DIR = ROOT / "backups"
PLAID_CONFIG_PATH = ROOT / "plaid_private_config.json"  # Existing Sandbox keys; retained for test history.
PLAID_STATE_PATH = ROOT / "plaid_private_state.json"
PLAID_PRODUCTION_CONFIG_PATH = ROOT / "plaid_production_private_config.json"
PLAID_PRODUCTION_STATE_PATH = ROOT / "plaid_production_private_state.json"
PLAID_ENVIRONMENT_PATH = ROOT / "plaid_environment.json"
HOST = "127.0.0.1"
PORT = int(os.environ.get("HOME_LEDGER_PORT", "8765"))
TRACKED_ACCOUNT_NAMES = ("5/3", "Capital One", "CIT", "House", "Mortgage", "Katie Roth", "Ryan Roth", "Fidelity", "Car", "Car Loan")
MORTGAGE_FORBEARANCE_BALANCE = 10559.64
APP_VERSION = "0.2.11"
UPDATE_CONFIG_PATH = ROOT / "update_settings.json"
DIAGNOSTIC_REPORT_URL = "https://home-ledger-report-service.rraftery12.workers.dev/api/duplicate-reports"
UPDATE_FILES = {"server.py", "backup_service.py", "duplicate_rules.py", "duplicate_service.py", "index.html", "polish.css", "recurring.js", "all-transactions-account.js", "transaction-split.js", "app-update.js", "VERSION.txt", "README.txt"}
PROFILE_REQUEST_LOCK = threading.RLock()


def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db


def create_daily_backup():
    """Create one complete snapshot of every budget and connection state per day."""
    data_files = ("profiles.json", "plaid_environment.json", "plaid_private_config.json", "plaid_private_state.json", "plaid_production_private_config.json", "plaid_production_private_state.json", "update_settings.json")
    app_files = ("server.py", "backup_service.py", "duplicate_rules.py", "duplicate_service.py", "index.html", "polish.css", "recurring.js", "all-transactions-account.js", "transaction-split.js", "app-update.js", "README.txt", "Start Home Ledger.bat", "Restore Home Ledger Backup.bat", "restore_backup.py")
    create_complete_daily_backup(ROOT, ROOT, BACKUP_DIR, ensure_profile_state().get("profiles", []), data_files, app_files)


def read_private_json(path):
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def write_private_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def version_parts(value):
    return tuple(int(part) for part in re.findall(r"\d+", str(value))[:3])


def read_update_manifest():
    settings = read_private_json(UPDATE_CONFIG_PATH)
    url = (settings.get("manifest_url") or "").strip()
    if not url:
        return url, None
    if urlparse(url).scheme != "https":
        raise ValueError("The update source must use HTTPS.")
    request = urllib.request.Request(url, headers={"User-Agent": f"Home-Ledger/{APP_VERSION}"})
    with urllib.request.urlopen(request, timeout=20) as response:
        if int(response.headers.get("Content-Length") or 0) > 100000:
            raise ValueError("The update information file is too large.")
        manifest = json.loads(response.read(100001))
    platform_key = "macos" if sys.platform == "darwin" else "windows" if os.name == "nt" else "linux"
    asset = (manifest.get("assets") or {}).get(platform_key) or {}
    result = {"version": str(manifest.get("version") or ""), "notes": str(manifest.get("notes") or ""), "url": str(asset.get("url") or ""), "sha256": str(asset.get("sha256") or "").lower(), "platform": platform_key}
    if not result["version"] or not result["url"] or not re.fullmatch(r"[0-9a-f]{64}", result["sha256"]):
        raise ValueError(f"The update information does not contain a valid {platform_key} package.")
    if urlparse(result["url"]).scheme != "https":
        raise ValueError("The update download must use HTTPS.")
    return url, result


def ensure_profile_state():
    state = read_private_json(PROFILE_CONFIG_PATH)
    if not state.get("profiles"):
        state = {"active": "home-ledger", "profiles": [{"id": "home-ledger", "name": "Home Ledger", "database": "home_ledger.sqlite3", "created_at": datetime.now().isoformat(timespec="seconds")}]}
        write_private_json(PROFILE_CONFIG_PATH, state)
    return state


def activate_profile(profile_id):
    global DB_PATH, ACTIVE_PROFILE_ID
    state = ensure_profile_state()
    profile = next((row for row in state["profiles"] if row["id"] == profile_id), None)
    if not profile:
        return None
    database = (ROOT / profile["database"]).resolve()
    if ROOT.resolve() not in database.parents and database != ROOT.resolve():
        return None
    ACTIVE_PROFILE_ID = profile_id
    DB_PATH = database
    state["active"] = profile_id
    write_private_json(PROFILE_CONFIG_PATH, state)
    return profile


class PlaidRequestError(ValueError):
    def __init__(self, message, code=""):
        super().__init__(message)
        self.code = code


def plaid_request(endpoint, payload, environment="production"):
    config_path = PLAID_PRODUCTION_CONFIG_PATH if environment == "production" else PLAID_CONFIG_PATH
    config = read_private_json(config_path)
    if not config.get("client_id") or not config.get("secret"):
        raise ValueError(f"Save your Plaid {environment.title()} credentials first.")
    body = {"client_id": config["client_id"], "secret": config["secret"], **payload}
    request = urllib.request.Request(
        f"https://{environment}.plaid.com" + endpoint,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "Plaid-Version": "2020-09-14"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read())
    except urllib.error.HTTPError as error:
        try:
            detail = json.loads(error.read())
            message = detail.get("display_message") or detail.get("error_message") or "Plaid request failed."
            code = detail.get("error_code") or ""
        except (json.JSONDecodeError, AttributeError):
            message = "Plaid request failed."
            code = ""
        raise PlaidRequestError(message, code) from error
    except urllib.error.URLError as error:
        raise ValueError("Home Ledger could not reach Plaid. Check your internet connection and try again.") from error


def active_plaid_environment():
    environment = (read_private_json(PLAID_ENVIRONMENT_PATH).get("environment") or "production").lower()
    return environment if environment in {"sandbox", "production"} else "production"


def active_plaid_paths():
    environment = active_plaid_environment()
    if environment == "sandbox":
        return environment, PLAID_CONFIG_PATH, PLAID_STATE_PATH
    return environment, PLAID_PRODUCTION_CONFIG_PATH, PLAID_PRODUCTION_STATE_PATH


def excel_date(serial):
    return (datetime(1899, 12, 30) + timedelta(days=float(serial))).date().isoformat()


def normalized_merchant(value):
    value = re.sub(r"[^A-Z0-9 ]", " ", (value or "").upper())
    ignored = {"THE", "INC", "LLC", "ONLINE", "PURCHASE", "PAYMENT", "DEBIT", "CREDIT", "CARD"}
    return " ".join(part for part in value.split() if part not in ignored)


def valid_category_rows(db):
    return list(db.execute(
        """
        SELECT DISTINCT c.id,c.name
        FROM categories c
        WHERE EXISTS (SELECT 1 FROM budget_lines bl WHERE bl.category_id=c.id)
           OR EXISTS (SELECT 1 FROM funds f WHERE f.name=c.name)
        ORDER BY c.name
        """
    ))


def transaction_already_in_ledger(db, account_id, amount, transaction_date, posted_date, description):
    start_date = min(date for date in (transaction_date, posted_date) if date)
    end_date = max(date for date in (transaction_date, posted_date) if date)
    candidates = list(db.execute(
        "SELECT transaction_date,posted_date,raw_description,description FROM transactions WHERE account_id=? AND source NOT IN ('plaid_production','plaid_sandbox') AND ABS(amount-?)<0.005 AND COALESCE(posted_date,transaction_date)>=date(?,'-62 day') AND transaction_date<=date(?,'+62 day')",
        (account_id, amount, start_date, end_date),
    ))
    incoming = normalized_merchant(description)
    incoming_dates = [datetime.strptime(value, "%Y-%m-%d").date() for value in (transaction_date, posted_date) if value]
    nearby = []
    for candidate in candidates:
        existing = normalized_merchant(candidate["raw_description"] or candidate["description"])
        existing_dates = [datetime.strptime(value, "%Y-%m-%d").date() for value in (candidate["transaction_date"], candidate["posted_date"]) if value]
        distance = min(abs((left - right).days) for left in incoming_dates for right in existing_dates)
        nearby.append((distance, candidate))
        descriptions_match = bool(incoming and existing and (incoming in existing or existing in incoming or SequenceMatcher(None, incoming, existing).ratio() >= 0.72))
        if descriptions_match and distance <= 14:
            return True
    very_close = [candidate for distance, candidate in nearby if distance <= 2]
    if len(very_close) == 1:
        return True
    plausible = [candidate for distance, candidate in nearby if distance <= 21]
    if len(plausible) == 1:
        return True
    return False


SCHEMA = [
    "CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, kind TEXT NOT NULL DEFAULT 'spending')",
    "CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, current_balance REAL NOT NULL DEFAULT 0, tracking_mode TEXT NOT NULL DEFAULT 'manual_monthly', active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER)",
    "CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY, legacy_id INTEGER UNIQUE, transaction_date TEXT NOT NULL, posted_date TEXT, raw_description TEXT, description TEXT NOT NULL, category_id INTEGER REFERENCES categories(id), amount REAL NOT NULL, account_id INTEGER REFERENCES accounts(id), card_last4 TEXT, source TEXT NOT NULL, source_fingerprint TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS inbox_transactions (id INTEGER PRIMARY KEY, fingerprint TEXT NOT NULL UNIQUE, transaction_date TEXT NOT NULL, posted_date TEXT, raw_description TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', category_id INTEGER REFERENCES categories(id), amount REAL NOT NULL, account_id INTEGER REFERENCES accounts(id), card_last4 TEXT, source_account_id TEXT, source TEXT NOT NULL DEFAULT 'capital_one_csv', imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS import_fingerprints (fingerprint TEXT PRIMARY KEY, first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS ignored_inbox_transactions (fingerprint TEXT PRIMARY KEY, ignored_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS duplicate_reviews (id INTEGER PRIMARY KEY, fingerprint TEXT NOT NULL UNIQUE, transaction_date TEXT NOT NULL, posted_date TEXT, raw_description TEXT NOT NULL, amount REAL NOT NULL, account_id INTEGER REFERENCES accounts(id), card_last4 TEXT, source_account_id TEXT, source TEXT NOT NULL, matched_transaction_id INTEGER REFERENCES transactions(id), reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, resolved_at TEXT)",
    "CREATE TABLE IF NOT EXISTS duplicate_audit (id INTEGER PRIMARY KEY, fingerprint TEXT NOT NULL, decision TEXT NOT NULL, reason TEXT NOT NULL, matched_transaction_id INTEGER REFERENCES transactions(id), repeat_count INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS plaid_pending_transactions (provider_transaction_id TEXT PRIMARY KEY, provider_account_id TEXT NOT NULL, transaction_date TEXT NOT NULL, description TEXT NOT NULL, amount REAL NOT NULL, source TEXT NOT NULL, first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS budget_periods (id INTEGER PRIMARY KEY, month TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'closed')",
    "CREATE TABLE IF NOT EXISTS budget_lines (id INTEGER PRIMARY KEY, period_id INTEGER NOT NULL REFERENCES budget_periods(id), category_id INTEGER NOT NULL REFERENCES categories(id), planned_amount REAL NOT NULL, sort_order INTEGER, UNIQUE(period_id, category_id))",
    "CREATE TABLE IF NOT EXISTS funds (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, balance REAL NOT NULL DEFAULT 0, starting_balance REAL NOT NULL DEFAULT 0, sort_order INTEGER)",
    "CREATE TABLE IF NOT EXISTS balance_snapshots (id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL REFERENCES accounts(id), snapshot_date TEXT NOT NULL, balance REAL NOT NULL, UNIQUE(account_id, snapshot_date))",
    "CREATE TABLE IF NOT EXISTS mortgage_schedule (payment_date TEXT PRIMARY KEY, principal_balance REAL NOT NULL)",
    "CREATE TABLE IF NOT EXISTS car_loan_schedule (payment_date TEXT PRIMARY KEY, principal_balance REAL NOT NULL)",
    "CREATE TABLE IF NOT EXISTS recurring_transactions (id INTEGER PRIMARY KEY,description TEXT NOT NULL,category_id INTEGER NOT NULL REFERENCES categories(id),amount REAL NOT NULL,account_id INTEGER REFERENCES accounts(id),frequency TEXT NOT NULL,start_date TEXT NOT NULL,next_date TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS transfer_templates (id INTEGER PRIMARY KEY,name TEXT NOT NULL,from_category_id INTEGER NOT NULL REFERENCES categories(id),to_category_id INTEGER NOT NULL REFERENCES categories(id),from_account_id INTEGER REFERENCES accounts(id),to_account_id INTEGER REFERENCES accounts(id),created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS bank_account_mappings (provider TEXT NOT NULL,environment TEXT NOT NULL,provider_account_id TEXT NOT NULL,provider_name TEXT NOT NULL,custom_name TEXT,mask TEXT,provider_balance REAL,ledger_account_id INTEGER REFERENCES accounts(id),active INTEGER NOT NULL DEFAULT 1,import_transactions INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(provider,environment,provider_account_id))",
    "CREATE TABLE IF NOT EXISTS sandbox_transactions (id INTEGER PRIMARY KEY,provider TEXT NOT NULL,provider_transaction_id TEXT NOT NULL UNIQUE,provider_account_id TEXT NOT NULL,transaction_date TEXT NOT NULL,description TEXT NOT NULL,user_description TEXT,category_id INTEGER REFERENCES categories(id),amount REAL NOT NULL,mask TEXT,promoted_transaction_id INTEGER REFERENCES transactions(id),imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    "CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(transaction_date)",
    "CREATE INDEX IF NOT EXISTS idx_transactions_category_date ON transactions(category_id, transaction_date)",
    "CREATE INDEX IF NOT EXISTS idx_inbox_imported ON inbox_transactions(imported_at)",
    "CREATE INDEX IF NOT EXISTS idx_balance_account_date ON balance_snapshots(account_id, snapshot_date)",
    "CREATE INDEX IF NOT EXISTS idx_sandbox_transactions_date ON sandbox_transactions(transaction_date)",
]


def initialize(blank=False):
    with connect() as db:
        for sql in SCHEMA:
            db.execute(sql)
        transaction_columns = {r["name"] for r in db.execute("PRAGMA table_info(transactions)")}
        if "source_fingerprint" not in transaction_columns:
            db.execute("ALTER TABLE transactions ADD COLUMN source_fingerprint TEXT")
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_transactions_source_fingerprint ON transactions(source_fingerprint) WHERE source_fingerprint IS NOT NULL")
        audit_columns = {r["name"] for r in db.execute("PRAGMA table_info(duplicate_audit)")}
        if "repeat_count" not in audit_columns:
            db.execute("ALTER TABLE duplicate_audit ADD COLUMN repeat_count INTEGER NOT NULL DEFAULT 1")
        if "last_seen_at" not in audit_columns:
            db.execute("ALTER TABLE duplicate_audit ADD COLUMN last_seen_at TEXT")
            db.execute("UPDATE duplicate_audit SET last_seen_at=created_at WHERE last_seen_at IS NULL")
        category_columns = {r["name"] for r in db.execute("PRAGMA table_info(categories)")}
        if "kind" not in category_columns:
            db.execute("ALTER TABLE categories ADD COLUMN kind TEXT NOT NULL DEFAULT 'spending'")
        db.execute("UPDATE categories SET kind='income' WHERE name IN ('Katie Income','Extra Income')")
        account_columns = {r["name"] for r in db.execute("PRAGMA table_info(accounts)")}
        if "active" not in account_columns:
            db.execute("ALTER TABLE accounts ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
            placeholders = ",".join("?" for _ in TRACKED_ACCOUNT_NAMES)
            db.execute(f"UPDATE accounts SET active=0 WHERE name NOT IN ({placeholders})", TRACKED_ACCOUNT_NAMES)
        if "sort_order" not in account_columns:
            db.execute("ALTER TABLE accounts ADD COLUMN sort_order INTEGER")
            for position, name in enumerate(TRACKED_ACCOUNT_NAMES):
                db.execute("UPDATE accounts SET sort_order=? WHERE name=?", (position, name))
        budget_line_columns = {r["name"] for r in db.execute("PRAGMA table_info(budget_lines)")}
        if "sort_order" not in budget_line_columns:
            db.execute("ALTER TABLE budget_lines ADD COLUMN sort_order INTEGER")
        fund_columns = {r["name"] for r in db.execute("PRAGMA table_info(funds)")}
        if "starting_balance" not in fund_columns:
            db.execute("ALTER TABLE funds ADD COLUMN starting_balance REAL NOT NULL DEFAULT 0")
        recurring_columns = {r["name"]: r for r in db.execute("PRAGMA table_info(recurring_transactions)")}
        if recurring_columns.get("account_id") and recurring_columns["account_id"]["notnull"]:
            db.execute("ALTER TABLE recurring_transactions RENAME TO recurring_transactions_required_account")
            db.execute("CREATE TABLE recurring_transactions (id INTEGER PRIMARY KEY,description TEXT NOT NULL,category_id INTEGER NOT NULL REFERENCES categories(id),amount REAL NOT NULL,account_id INTEGER REFERENCES accounts(id),frequency TEXT NOT NULL,start_date TEXT NOT NULL,next_date TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
            db.execute("INSERT INTO recurring_transactions SELECT * FROM recurring_transactions_required_account")
            db.execute("DROP TABLE recurring_transactions_required_account")
        if "sort_order" not in fund_columns:
            db.execute("ALTER TABLE funds ADD COLUMN sort_order INTEGER")
        db.execute("INSERT INTO transactions(transaction_date,description,category_id,amount,source) SELECT date('now'),'Starting balance',c.id,f.starting_balance,'fund_adjustment' FROM funds f JOIN categories c ON c.name=f.name WHERE ABS(f.starting_balance)>0.004")
        db.execute("UPDATE funds SET starting_balance=0 WHERE ABS(starting_balance)>0.004")
        sandbox_columns = {r["name"] for r in db.execute("PRAGMA table_info(sandbox_transactions)")}
        if "user_description" not in sandbox_columns:
            db.execute("ALTER TABLE sandbox_transactions ADD COLUMN user_description TEXT")
        if "category_id" not in sandbox_columns:
            db.execute("ALTER TABLE sandbox_transactions ADD COLUMN category_id INTEGER REFERENCES categories(id)")
        if "promoted_transaction_id" not in sandbox_columns:
            db.execute("ALTER TABLE sandbox_transactions ADD COLUMN promoted_transaction_id INTEGER REFERENCES transactions(id)")
        inbox_columns = {r["name"] for r in db.execute("PRAGMA table_info(inbox_transactions)")}
        if "source" not in inbox_columns:
            db.execute("ALTER TABLE inbox_transactions ADD COLUMN source TEXT NOT NULL DEFAULT 'capital_one_csv'")
        if "source_account_id" not in inbox_columns:
            db.execute("ALTER TABLE inbox_transactions ADD COLUMN source_account_id TEXT")
        mapping_columns = {r["name"] for r in db.execute("PRAGMA table_info(bank_account_mappings)")}
        if "custom_name" not in mapping_columns:
            db.execute("ALTER TABLE bank_account_mappings ADD COLUMN custom_name TEXT")
        if "import_transactions" not in mapping_columns:
            db.execute("ALTER TABLE bank_account_mappings ADD COLUMN import_transactions INTEGER NOT NULL DEFAULT 1")
        if "provider_balance" not in mapping_columns:
            db.execute("ALTER TABLE bank_account_mappings ADD COLUMN provider_balance REAL")
        if blank:
            db.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('workbook_migrated',?)", (datetime.now().isoformat(),))
            db.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('active_budget_month',?)", (datetime.now().strftime("%Y-%m"),))
            return
        migrated = db.execute("SELECT value FROM metadata WHERE key='workbook_migrated'").fetchone()
        if migrated or not SEED_PATH.exists():
            return
        seed = json.loads(SEED_PATH.read_text(encoding="utf-8"))
        category_ids = {}
        for name in seed["categories"]:
            db.execute("INSERT OR IGNORE INTO categories(name) VALUES(?)", (name,))
        for row in db.execute("SELECT id,name FROM categories"):
            category_ids[row["name"]] = row["id"]
        account_names = {t["account"] for t in seed["transactions"]} | {a["name"] for a in seed["accounts"]}
        for name in sorted(account_names):
            current = next((a["currentBalance"] for a in seed["accounts"] if a["name"] == name), 0)
            mode = "transaction_derived" if name in {"Capital One", "Discover", "5/3"} else "manual_monthly"
            db.execute("INSERT OR IGNORE INTO accounts(name,current_balance,tracking_mode) VALUES(?,?,?)", (name, current, mode))
        account_ids = {r["name"]: r["id"] for r in db.execute("SELECT id,name FROM accounts")}
        tx_rows = []
        for t in seed["transactions"]:
            tx_rows.append((t["legacyId"], excel_date(t["dateSerial"]), t["description"], category_ids.get(t["category"]), t["amount"], account_ids[t["account"]], "workbook"))
        db.executemany("INSERT OR IGNORE INTO transactions(legacy_id,transaction_date,description,category_id,amount,account_id,source) VALUES(?,?,?,?,?,?,?)", tx_rows)
        for b in seed["budgets"]:
            db.execute("INSERT OR IGNORE INTO budget_periods(month) VALUES(?)", (b["period"],))
            pid = db.execute("SELECT id FROM budget_periods WHERE month=?", (b["period"],)).fetchone()[0]
            cid = category_ids.get(b["category"])
            if cid:
                db.execute("INSERT INTO budget_lines(period_id,category_id,planned_amount) VALUES(?,?,?) ON CONFLICT(period_id,category_id) DO UPDATE SET planned_amount=excluded.planned_amount", (pid, cid, b["planned"]))
        for f in seed["funds"]:
            db.execute("INSERT OR REPLACE INTO funds(name,balance) VALUES(?,?)", (f["name"], f["balance"]))
        for s in seed["balanceSnapshots"]:
            aid = account_ids.get(s["account"])
            if aid:
                db.execute("INSERT OR IGNORE INTO balance_snapshots(account_id,snapshot_date,balance) VALUES(?,?,?)", (aid, excel_date(s["dateSerial"]), s["balance"]))
        db.execute("INSERT INTO metadata(key,value) VALUES('workbook_migrated',?)", (datetime.now().isoformat(),))
        db.execute("PRAGMA optimize")


def fingerprint(row):
    raw = "|".join([row["transaction_date"], row["posted_date"], row["card_last4"], row["raw_description"].strip().lower(), f'{row["amount"]:.2f}'])
    return hashlib.sha256(raw.encode()).hexdigest()


def run_monthly_rollover():
    current_month = datetime.now().strftime("%Y-%m")
    first_date = current_month + "-01"
    with connect() as db:
        active_row = db.execute("SELECT value FROM metadata WHERE key='active_budget_month'").fetchone()
        active_month = active_row["value"] if active_row else None

        # Establish the current month without generating historical entries when
        # this feature is installed into an already-used ledger.
        if active_month is None:
            db.execute("UPDATE budget_periods SET status='closed'")
            db.execute("UPDATE budget_periods SET status='current' WHERE month=?", (current_month,))
            db.execute("INSERT INTO metadata(key,value) VALUES('active_budget_month',?)", (current_month,))
            return
        if active_month == current_month:
            return

        previous_period = db.execute("SELECT id FROM budget_periods WHERE month=?", (active_month,)).fetchone()
        if not previous_period:
            previous_period = db.execute("SELECT id FROM budget_periods WHERE month<? ORDER BY month DESC LIMIT 1", (current_month,)).fetchone()
        db.execute("INSERT OR IGNORE INTO budget_periods(month,status) VALUES(?,'current')", (current_month,))
        current_period_id = db.execute("SELECT id FROM budget_periods WHERE month=?", (current_month,)).fetchone()[0]
        if previous_period:
            db.execute("INSERT OR IGNORE INTO budget_lines(period_id,category_id,planned_amount) SELECT ?,category_id,planned_amount FROM budget_lines WHERE period_id=?", (current_period_id, previous_period["id"]))
        db.execute("UPDATE budget_periods SET status='closed'")
        db.execute("UPDATE budget_periods SET status='current' WHERE id=?", (current_period_id,))

        category_ids = {r["name"]: r["id"] for r in db.execute("SELECT id,name FROM categories")}
        transfer_account = db.execute("SELECT id FROM accounts WHERE name='Transfer'").fetchone()
        month_label = datetime.strptime(first_date, "%Y-%m-%d").strftime("%m/%y")
        monthly_rows = [
            ("Transfer to Savings for Roth", "Roth", -1250.0),
            ("Transfer to Gifts", "Transfer", -200.0),
            ("Transfer to Vacation", "Transfer", -1000.0),
            (f"Transfer from ({month_label})", "Vacation/Hosting", 1000.0),
            (f"Transfer from ({month_label})", "Gifts", 200.0),
            (f"Transfer from ({month_label}) for Roth", "Savings", 1250.0),
        ]
        if transfer_account and all(category in category_ids for _, category, _ in monthly_rows):
            for description, category, amount in monthly_rows:
                exists = db.execute("SELECT 1 FROM transactions WHERE transaction_date=? AND description=? AND category_id=? AND amount=? AND account_id=? AND source='monthly_automation'", (first_date, description, category_ids[category], amount, transfer_account["id"])).fetchone()
                if not exists:
                    db.execute("INSERT INTO transactions(transaction_date,description,category_id,amount,account_id,source) VALUES(?,?,?,?,?,'monthly_automation')", (first_date, description, category_ids[category], amount, transfer_account["id"]))
                    db.execute("UPDATE funds SET balance=balance+? WHERE name=?", (amount, category))
        db.execute("INSERT INTO metadata(key,value) VALUES('active_budget_month',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (current_month,))


def next_recurring_date(value, frequency, start_date=None):
    current = datetime.strptime(value, "%Y-%m-%d").date()
    if frequency == "daily":
        return (current + timedelta(days=1)).isoformat()
    if frequency == "weekly":
        return (current + timedelta(days=7)).isoformat()
    if frequency == "biweekly":
        return (current + timedelta(days=14)).isoformat()
    months = {"monthly": 1, "quarterly": 3, "yearly": 12}[frequency]
    month_index = current.year * 12 + current.month - 1 + months
    year, month_zero = divmod(month_index, 12)
    month = month_zero + 1
    anchor_day = datetime.strptime(start_date, "%Y-%m-%d").day if start_date else current.day
    day = min(anchor_day, calendar.monthrange(year, month)[1])
    return datetime(year, month, day).date().isoformat()


def run_recurring_transactions():
    today = datetime.now().date().isoformat()
    with connect() as db:
        rules = list(db.execute("SELECT * FROM recurring_transactions WHERE active=1 AND next_date<=? ORDER BY next_date,id", (today,)))
        for rule in rules:
            next_date = rule["next_date"]
            while next_date <= today:
                db.execute("INSERT INTO transactions(transaction_date,description,category_id,amount,account_id,source) VALUES(?,?,?,?,?,?)", (next_date, rule["description"], rule["category_id"], rule["amount"], rule["account_id"], f"recurring:{rule['id']}"))
                db.execute("UPDATE funds SET balance=balance+? WHERE name=(SELECT name FROM categories WHERE id=?)", (rule["amount"], rule["category_id"]))
                db.execute("UPDATE accounts SET current_balance=current_balance+? WHERE id=? AND tracking_mode='transaction_derived'", (rule["amount"], rule["account_id"]))
                next_date = next_recurring_date(next_date, rule["frequency"], rule["start_date"])
            db.execute("UPDATE recurring_transactions SET next_date=? WHERE id=?", (next_date, rule["id"]))


def json_response(handler, payload, status=200):
    body = json.dumps(payload).encode()
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, fmt, *args):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        with PROFILE_REQUEST_LOCK:
            return self._do_GET()

    def _do_GET(self):
        requested_path = urlparse(self.path).path
        if requested_path.startswith("/backups/") or Path(requested_path).suffix.lower() in {".sqlite3", ".json", ".py", ".bat"}:
            return json_response(self, {"error": "Not found"}, 404)
        if self.path.startswith("/api/funds"):
            return self.fund_transactions(parse_qs(urlparse(self.path).query))
        parsed = urlparse(self.path)
        if parsed.path == "/api/profiles":
            return self.profiles()
        if parsed.path == "/api/bootstrap":
            return self.bootstrap(parse_qs(parsed.query))
        if parsed.path == "/api/inbox":
            return self.inbox()
        if parsed.path == "/api/duplicates":
            return self.duplicate_reviews()
        if parsed.path == "/api/budget-setup":
            return self.budget_setup(parse_qs(parsed.query))
        if parsed.path == "/api/transactions":
            return self.transactions(parse_qs(parsed.query))
        if parsed.path == "/api/recurring":
            return self.recurring_transactions()
        if parsed.path == "/api/transfer-templates":
            return self.transfer_templates()
        if parsed.path == "/api/budget-transactions":
            return self.budget_transactions(parse_qs(parsed.query))
        if parsed.path == "/api/account-plaid-transactions":
            return self.account_plaid_transactions(parse_qs(parsed.query))
        if parsed.path == "/api/health":
            return json_response(self, {"ok": True})
        if parsed.path == "/api/update/status":
            return self.update_status()
        if parsed.path == "/api/plaid/status":
            return self.plaid_status()
        if parsed.path == "/api/plaid/recent":
            return self.plaid_recent(parsed)
        if parsed.path == "/api/plaid/sandbox":
            return self.plaid_sandbox()
        if parsed.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        with PROFILE_REQUEST_LOCK:
            return self._do_POST()

    def _do_POST(self):
        if self.path == "/api/profiles/create":
            return self.create_profile(self.read_json())
        if self.path == "/api/profiles/switch":
            return self.switch_profile(self.read_json())
        if self.path == "/api/profiles/delete":
            return self.delete_profile(self.read_json())
        if self.path == "/api/inbox/save":
            return self.save_inbox(self.read_json())
        if self.path == "/api/inbox/submit":
            return self.submit_inbox(self.read_json())
        if self.path == "/api/inbox/delete":
            return self.delete_inbox_transaction(self.read_json())
        if self.path == "/api/inbox/delete-many":
            return self.delete_inbox_transactions(self.read_json())
        if self.path == "/api/inbox/report-duplicate":
            return self.report_inbox_duplicate(self.read_json())
        if self.path == "/api/duplicates/keep":
            return self.resolve_duplicate(self.read_json(), keep=True)
        if self.path == "/api/duplicates/dismiss":
            return self.resolve_duplicate(self.read_json(), keep=False)
        if self.path == "/api/budget-setup/save":
            return self.save_budget_setup(self.read_json())
        if self.path == "/api/transactions/save":
            return self.save_transactions(self.read_json())
        if self.path == "/api/transactions/split":
            return self.split_transaction(self.read_json())
        if self.path == "/api/inbox/split":
            return self.split_inbox_transaction(self.read_json())
        if self.path == "/api/transactions/transfer":
            return self.create_internal_transfer(self.read_json())
        if self.path == "/api/transactions/delete":
            return self.delete_transaction(self.read_json())
        if self.path == "/api/recurring/create":
            return self.create_recurring_transaction(self.read_json())
        if self.path == "/api/recurring/update":
            return self.update_recurring_transaction(self.read_json())
        if self.path == "/api/recurring/delete":
            return self.delete_recurring_transaction(self.read_json())
        if self.path == "/api/transfer-templates/create":
            return self.create_transfer_template(self.read_json())
        if self.path == "/api/transfer-templates/delete":
            return self.delete_transfer_template(self.read_json())
        if self.path == "/api/accounts/save":
            return self.save_accounts(self.read_json())
        if self.path == "/api/accounts/create":
            return self.create_account(self.read_json())
        if self.path == "/api/accounts/delete":
            return self.delete_account(self.read_json())
        if self.path == "/api/accounts/reorder":
            return self.reorder_accounts(self.read_json())
        if self.path == "/api/funds/create":
            return self.create_fund(self.read_json())
        if self.path == "/api/funds/adjust":
            return self.adjust_fund(self.read_json())
        if self.path == "/api/funds/rename":
            return self.rename_fund(self.read_json())
        if self.path == "/api/funds/delete":
            return self.delete_fund(self.read_json())
        if self.path == "/api/funds/reorder":
            return self.reorder_funds(self.read_json())
        if self.path == "/api/plaid/settings":
            return self.save_plaid_settings(self.read_json())
        if self.path == "/api/update/settings":
            return self.save_update_settings(self.read_json())
        if self.path == "/api/update/install":
            return self.install_update()
        if self.path == "/api/plaid/link-token":
            return self.plaid_link_token(self.read_json())
        if self.path == "/api/plaid/exchange":
            return self.plaid_exchange(self.read_json())
        if self.path == "/api/plaid/sync":
            return self.plaid_sync()
        if self.path == "/api/plaid/mappings":
            return self.save_plaid_mappings(self.read_json())
        if self.path == "/api/plaid/sandbox/clear":
            return self.clear_plaid_sandbox()
        if self.path == "/api/plaid/sandbox/submit":
            return self.submit_plaid_sandbox(self.read_json())
        return json_response(self, {"error": "Not found"}, 404)

    def profiles(self):
        state = ensure_profile_state()
        json_response(self, {"active": ACTIVE_PROFILE_ID, "profiles": state["profiles"]})

    def update_status(self):
        manifest_url = (read_private_json(UPDATE_CONFIG_PATH).get("manifest_url") or "").strip()
        if not manifest_url:
            return json_response(self, {"currentVersion": APP_VERSION, "configured": False, "manifestUrl": "", "available": False})
        try:
            _, manifest = read_update_manifest()
            available = version_parts(manifest["version"]) > version_parts(APP_VERSION)
            json_response(self, {"currentVersion": APP_VERSION, "configured": True, "manifestUrl": manifest_url, "available": available, **manifest})
        except (OSError, ValueError, json.JSONDecodeError, urllib.error.URLError) as error:
            json_response(self, {"error": f"Home Ledger could not check for updates: {error}"}, 502)

    def save_update_settings(self, payload):
        manifest_url = (payload.get("manifestUrl") or "").strip()
        if manifest_url and urlparse(manifest_url).scheme != "https":
            return json_response(self, {"error": "The update source must begin with https://"}, 400)
        write_private_json(UPDATE_CONFIG_PATH, {"manifest_url": manifest_url})
        json_response(self, {"saved": True, "configured": bool(manifest_url)})

    def install_update(self):
        try:
            _, manifest = read_update_manifest()
            if not manifest or version_parts(manifest["version"]) <= version_parts(APP_VERSION):
                return json_response(self, {"error": "Home Ledger is already up to date."}, 400)
            request = urllib.request.Request(manifest["url"], headers={"User-Agent": f"Home-Ledger/{APP_VERSION}"})
            archive_path = ROOT / "pending-update.zip"
            digest, total = hashlib.sha256(), 0
            with urllib.request.urlopen(request, timeout=60) as response, archive_path.open("wb") as destination:
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > 100 * 1024 * 1024:
                        raise ValueError("The update package is larger than 100 MB.")
                    digest.update(chunk)
                    destination.write(chunk)
            if digest.hexdigest().lower() != manifest["sha256"]:
                raise ValueError("The update package failed its security check and was not installed.")
            staging = ROOT / "update-staging"
            if staging.exists():
                shutil.rmtree(staging)
            staging.mkdir(parents=True)
            found = {}
            with zipfile.ZipFile(archive_path) as archive:
                if sum(item.file_size for item in archive.infolist()) > 100 * 1024 * 1024:
                    raise ValueError("The extracted update is larger than 100 MB.")
                for item in archive.infolist():
                    name = Path(item.filename).name
                    if not name or name not in UPDATE_FILES:
                        continue
                    if name in found:
                        raise ValueError(f"The update contains more than one {name} file.")
                    target = staging / name
                    with archive.open(item) as source, target.open("wb") as destination:
                        shutil.copyfileobj(source, destination)
                    found[name] = target
            if not {"server.py", "index.html", "app-update.js"}.issubset(found):
                raise ValueError("The update package is missing required application files.")
            backup = BACKUP_DIR / f"before-update-{APP_VERSION}-to-{manifest['version']}-{datetime.now():%Y%m%d-%H%M%S}"
            backup.mkdir(parents=True, exist_ok=False)
            for name in UPDATE_FILES:
                current = ROOT / name
                if current.exists():
                    shutil.copy2(current, backup / name)
            for name, staged in found.items():
                os.replace(staged, ROOT / name)
            archive_path.unlink(missing_ok=True)
            shutil.rmtree(staging, ignore_errors=True)
            json_response(self, {"installed": True, "version": manifest["version"], "restarting": True})
            def restart_app():
                subprocess.Popen([sys.executable, str(ROOT / "server.py")], cwd=str(ROOT))
                os._exit(0)
            threading.Timer(1.0, restart_app).start()
        except (OSError, ValueError, json.JSONDecodeError, urllib.error.URLError, zipfile.BadZipFile) as error:
            json_response(self, {"error": f"The update was not installed: {error}"}, 400)

    def create_profile(self, payload):
        name = (payload.get("name") or "").strip()
        if not name:
            return json_response(self, {"error": "Enter a name for the new budget."}, 400)
        state = ensure_profile_state()
        if any(row["name"].casefold() == name.casefold() for row in state["profiles"]):
            return json_response(self, {"error": "A budget with that name already exists."}, 400)
        profile_id = uuid.uuid4().hex[:12]
        PROFILE_DB_DIR.mkdir(parents=True, exist_ok=True)
        profile = {"id": profile_id, "name": name, "database": f"profiles/{profile_id}.sqlite3", "created_at": datetime.now().isoformat(timespec="seconds")}
        state["profiles"].append(profile)
        state["active"] = profile_id
        write_private_json(PROFILE_CONFIG_PATH, state)
        activate_profile(profile_id)
        initialize(blank=True)
        run_monthly_rollover()
        json_response(self, {"created": True, "profile": profile})

    def switch_profile(self, payload):
        profile = activate_profile((payload.get("id") or "").strip())
        if not profile:
            return json_response(self, {"error": "That budget profile could not be found."}, 404)
        initialize(blank=profile["id"] != "home-ledger" and not DB_PATH.exists())
        run_monthly_rollover()
        json_response(self, {"switched": True, "profile": profile})

    def delete_profile(self, payload):
        profile_id = (payload.get("id") or "").strip()
        state = ensure_profile_state()
        profile = next((row for row in state["profiles"] if row["id"] == profile_id), None)
        if not profile:
            return json_response(self, {"error": "That budget could not be found."}, 404)
        if len(state["profiles"]) <= 1:
            return json_response(self, {"error": "Create another budget before deleting the final budget."}, 400)
        database = (ROOT / profile["database"]).resolve()
        if ROOT.resolve() not in database.parents and database != ROOT.resolve():
            return json_response(self, {"error": "That budget database location is not safe to remove."}, 400)
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^A-Za-z0-9_-]+", "-", profile["name"]).strip("-") or "budget"
        backup_path = BACKUP_DIR / f"deleted-budget-{safe_name}-{datetime.now():%Y%m%d-%H%M%S}.sqlite3"
        if database.exists():
            source_db = sqlite3.connect(database)
            backup_db = sqlite3.connect(backup_path)
            try:
                source_db.backup(backup_db)
            finally:
                backup_db.close()
                source_db.close()
        remaining = [row for row in state["profiles"] if row["id"] != profile_id]
        state["profiles"] = remaining
        if state.get("active") == profile_id:
            state["active"] = remaining[0]["id"]
        write_private_json(PROFILE_CONFIG_PATH, state)
        if ACTIVE_PROFILE_ID == profile_id:
            activate_profile(state["active"])
            initialize(blank=ACTIVE_PROFILE_ID != "home-ledger" and not DB_PATH.exists())
        if database.exists():
            database.unlink()
        json_response(self, {"deleted": True, "name": profile["name"], "active": state["active"], "backup": backup_path.name})

    def plaid_status(self):
        environment, config_path, state_path = active_plaid_paths()
        config = read_private_json(config_path)
        state = read_private_json(state_path)
        items = state.get("items", [])
        account_ids = [account_id for item in items for account_id in item.get("account_ids", [])]
        with connect() as db:
            capital_one = db.execute("SELECT id FROM accounts WHERE name='Capital One'").fetchone()
            default_active = 1 if ACTIVE_PROFILE_ID == "home-ledger" else 0
            for item in items:
                for account_id in item.get("account_ids", []):
                    db.execute("INSERT OR IGNORE INTO bank_account_mappings(provider,environment,provider_account_id,provider_name,mask,ledger_account_id,active) VALUES('plaid',?,?,?,?,?,?)", (environment, account_id, item.get("account_names", {}).get(account_id, "Connected account"), item.get("account_masks", {}).get(account_id, ""), capital_one["id"] if capital_one and default_active else None, default_active))
            mappings = [dict(r) for r in db.execute("SELECT m.provider_account_id accountId,m.provider_name providerName,COALESCE(m.custom_name,'') customName,m.mask,m.provider_balance providerBalance,a.name ledgerAccount,m.import_transactions importTransactions,m.active attached FROM bank_account_mappings m LEFT JOIN accounts a ON a.id=m.ledger_account_id WHERE m.provider='plaid' AND m.environment=? ORDER BY m.active DESC,COALESCE(NULLIF(m.custom_name,''),m.provider_name),m.mask", (environment,))]
            item_health = {}
            for item in items:
                status = item.get("connection_status") or "connected"
                message = item.get("connection_message") or ""
                for account_id in item.get("account_ids", []):
                    item_health[account_id] = {"connectionStatus": status, "connectionMessage": message}
            for mapping in mappings:
                mapping.update(item_health.get(mapping["accountId"], {"connectionStatus": "disconnected", "connectionMessage": "The Plaid connection is no longer available."}))
            ledger_accounts = [r["name"] for r in db.execute("SELECT name FROM accounts WHERE active=1 ORDER BY name")]
            sandbox_count = db.execute("SELECT COUNT(*) FROM sandbox_transactions").fetchone()[0]
            attached_count = sum(1 for row in mappings if row["attached"])
        json_response(self, {
            "configured": bool(config.get("client_id") and config.get("secret")),
            "connected": bool(items),
            "environment": environment.title(),
            "profileCount": len(ensure_profile_state().get("profiles", [])),
            "availableSharedAccountCount": sum(1 for row in mappings if not row["attached"]),
            "accountCount": len(account_ids),
            "attachedAccountCount": attached_count,
            "institutionCount": len(items),
            "lastSync": max(((item.get("profile_last_sync") or {}).get(ACTIVE_PROFILE_ID) or (item.get("last_sync") if ACTIVE_PROFILE_ID == "home-ledger" else "") or "" for item in items), default="") or None,
            "mappings": mappings,
            "ledgerAccounts": ledger_accounts,
            "sandboxCount": sandbox_count,
        })

    def plaid_sandbox(self):
        with connect() as db:
            rows = [dict(r) for r in db.execute("SELECT s.id,s.transaction_date transactionDate,s.description originalDescription,COALESCE(s.user_description,'') userDescription,c.name category,s.amount,s.mask,COALESCE(a.name,'Unmapped') ledgerAccount,s.promoted_transaction_id IS NOT NULL promoted FROM sandbox_transactions s LEFT JOIN categories c ON c.id=s.category_id LEFT JOIN bank_account_mappings m ON m.provider='plaid' AND m.environment='sandbox' AND m.provider_account_id=s.provider_account_id LEFT JOIN accounts a ON a.id=m.ledger_account_id ORDER BY s.id")]
            categories = [r["name"] for r in valid_category_rows(db)]
        json_response(self, {"rows": rows, "count": len(rows), "categories": categories})

    def plaid_recent(self, parsed):
        query = parse_qs(parsed.query)
        account_id = (query.get("accountId") or [""])[0].strip()
        days = min(max(int((query.get("days") or ["30"])[0]), 1), 90)
        environment, _, state_path = active_plaid_paths()
        state = read_private_json(state_path)
        item = next((row for row in state.get("items", []) if account_id in row.get("account_ids", [])), None)
        if not item:
            return json_response(self, {"error": "That Plaid account could not be found."}, 404)
        try:
            result = plaid_request("/transactions/get", {
                "access_token": item["access_token"],
                "start_date": (datetime.now().date() - timedelta(days=days)).isoformat(),
                "end_date": datetime.now().date().isoformat(),
                "options": {"account_ids": [account_id], "count": 500, "offset": 0},
            }, environment)
        except ValueError as error:
            return json_response(self, {"error": str(error)}, 400)
        rows = []
        for transaction in result.get("transactions", []):
            provider_id = transaction.get("transaction_id") or ""
            rows.append({
                "fingerprint": hashlib.sha256((f"plaid-{environment}:" + provider_id).encode()).hexdigest(),
                "transactionDate": transaction.get("authorized_date") or transaction.get("date"),
                "postedDate": transaction.get("date"),
                "description": transaction.get("merchant_name") or transaction.get("name") or "Plaid transaction",
                "amount": -float(transaction.get("amount") or 0),
                "pending": bool(transaction.get("pending")),
            })
        json_response(self, {"rows": rows, "count": len(rows)})

    def save_plaid_settings(self, payload):
        client_id = (payload.get("clientId") or "").strip()
        secret = (payload.get("secret") or "").strip()
        environment = (payload.get("environment") or "production").strip().lower()
        if environment not in {"sandbox", "production"}:
            return json_response(self, {"error": "Choose Sandbox or Production."}, 400)
        if not client_id or not secret:
            return json_response(self, {"error": f"Enter both the Plaid client ID and {environment.title()} secret."}, 400)
        config_path = PLAID_CONFIG_PATH if environment == "sandbox" else PLAID_PRODUCTION_CONFIG_PATH
        state_path = PLAID_STATE_PATH if environment == "sandbox" else PLAID_PRODUCTION_STATE_PATH
        write_private_json(PLAID_ENVIRONMENT_PATH, {"environment": environment})
        write_private_json(config_path, {"client_id": client_id, "secret": secret, "environment": environment})
        old_state = read_private_json(state_path)
        if not old_state:
            write_private_json(state_path, {"client_user_id": str(uuid.uuid4()), "items": []})
        json_response(self, {"saved": True, "environment": environment.title()})

    def plaid_link_token(self, payload):
        environment, _, state_path = active_plaid_paths()
        state = read_private_json(state_path)
        purpose = "investments" if payload.get("purpose") == "investments" else "transactions"
        client_user_id = state.get("client_user_id") or str(uuid.uuid4())
        state["client_user_id"] = client_user_id
        state.setdefault("items", [])
        write_private_json(state_path, state)
        repair_account_id = (payload.get("repairAccountId") or "").strip()
        repair_item = next((item for item in state.get("items", []) if repair_account_id in item.get("account_ids", [])), None)
        if repair_account_id and not repair_item:
            return json_response(self, {"error": "That Plaid connection could not be found."}, 404)
        link_payload = {
                "client_name": "Home Ledger",
                "language": "en",
                "country_codes": ["US"],
                "user": {"client_user_id": client_user_id},
            }
        if repair_item:
            link_payload["access_token"] = repair_item["access_token"]
        else:
            link_payload["products"] = [purpose]
        try:
            result = plaid_request("/link/token/create", link_payload, environment)
        except ValueError as error:
            return json_response(self, {"error": str(error)}, 400)
        json_response(self, {"linkToken": result["link_token"], "repair": bool(repair_item)})

    def plaid_exchange(self, payload):
        environment, _, state_path = active_plaid_paths()
        public_token = (payload.get("publicToken") or "").strip()
        if not public_token:
            return json_response(self, {"error": "Plaid did not return a connection token."}, 400)
        try:
            exchanged = plaid_request("/item/public_token/exchange", {"public_token": public_token}, environment)
            accounts = plaid_request("/accounts/get", {"access_token": exchanged["access_token"]}, environment).get("accounts", [])
        except ValueError as error:
            return json_response(self, {"error": str(error)}, 400)
        selected = set(payload.get("accountIds") or [])
        if not selected:
            selected = {account["account_id"] for account in accounts}
        state = read_private_json(state_path)
        item = {
            "access_token": exchanged["access_token"],
            "item_id": exchanged["item_id"],
            "account_ids": sorted(selected),
            "account_masks": {account["account_id"]: account.get("mask") or "" for account in accounts},
            "account_names": {account["account_id"]: account.get("name") or account.get("official_name") or "Connected account" for account in accounts},
            "cursor": None,
            "last_sync": None,
            "product": "investments" if payload.get("purpose") == "investments" else "transactions",
        }
        items = [existing for existing in state.get("items", []) if existing.get("item_id") != item["item_id"]]
        items.append(item)
        state["items"] = items
        state.setdefault("client_user_id", str(uuid.uuid4()))
        write_private_json(state_path, state)
        with connect() as db:
            capital_one = db.execute("SELECT id FROM accounts WHERE name='Capital One'").fetchone()
            for account in accounts:
                if account["account_id"] in selected:
                    provider_name = (account.get("name") or account.get("official_name") or "").upper()
                    if "5/3" in provider_name or "FIFTH THIRD" in provider_name:
                        default_account = db.execute("SELECT id FROM accounts WHERE name='5/3'").fetchone()
                    elif account.get("type") == "credit" and ("DISCOVER" in provider_name or "CAPITAL ONE" in provider_name):
                        default_account = capital_one
                    else:
                        default_account = None
                    default_ledger_id = default_account["id"] if default_account else None
                    db.execute("INSERT INTO bank_account_mappings(provider,environment,provider_account_id,provider_name,mask,ledger_account_id) VALUES('plaid',?,?,?,?,?) ON CONFLICT(provider,environment,provider_account_id) DO UPDATE SET provider_name=excluded.provider_name,mask=excluded.mask", (environment, account["account_id"], account.get("name") or account.get("official_name") or "Connected account", account.get("mask") or "", default_ledger_id))
        json_response(self, {"connected": True, "accountCount": len(selected)})

    def save_plaid_mappings(self, payload):
        rows = payload.get("rows", [])
        environment, _, state_path = active_plaid_paths()
        source = f"plaid_{environment}"
        state = read_private_json(state_path)
        reset_history = False
        with connect() as db:
            account_ids = {r["name"]: r["id"] for r in db.execute("SELECT id,name FROM accounts WHERE active=1")}
            for row in rows:
                attached = 1 if row.get("attached") else 0
                ledger_account = row.get("ledgerAccount") or ""
                if ledger_account and ledger_account not in account_ids:
                    return json_response(self, {"error": "Choose a valid Home Ledger account or Ignore for now."}, 400)
                current = db.execute("SELECT ledger_account_id,mask,import_transactions,active FROM bank_account_mappings WHERE provider='plaid' AND environment=? AND provider_account_id=?", (environment, row.get("accountId"))).fetchone()
                if current and attached and (current["ledger_account_id"] is None or not current["active"]) and ledger_account:
                    reset_history = True
                db.execute("UPDATE bank_account_mappings SET ledger_account_id=? WHERE provider='plaid' AND environment=? AND provider_account_id=?", (account_ids.get(ledger_account), environment, row.get("accountId")))
                db.execute("UPDATE bank_account_mappings SET custom_name=? WHERE provider='plaid' AND environment=? AND provider_account_id=?", (((row.get("customName") or "").strip() or None), environment, row.get("accountId")))
                db.execute("UPDATE bank_account_mappings SET active=? WHERE provider='plaid' AND environment=? AND provider_account_id=?", (attached, environment, row.get("accountId")))
                import_transactions = 1 if row.get("importTransactions", True) else 0
                db.execute("UPDATE bank_account_mappings SET import_transactions=? WHERE provider='plaid' AND environment=? AND provider_account_id=?", (import_transactions, environment, row.get("accountId")))
                if not import_transactions and current:
                    db.execute("DELETE FROM inbox_transactions WHERE source=? AND (source_account_id=? OR (source_account_id IS NULL AND card_last4=?))", (source, row.get("accountId"), current["mask"]))
                if not ledger_account and current and current["mask"]:
                    db.execute("DELETE FROM inbox_transactions WHERE source=? AND card_last4=?", (source, current["mask"]))
                if not attached and current:
                    db.execute("DELETE FROM inbox_transactions WHERE source=? AND (source_account_id=? OR (source_account_id IS NULL AND card_last4=?))", (source, row.get("accountId"), current["mask"]))
            db.execute("UPDATE accounts SET current_balance=0 WHERE tracking_mode='plaid_balance' AND NOT EXISTS (SELECT 1 FROM bank_account_mappings m WHERE m.provider='plaid' AND m.environment=? AND m.active=1 AND m.ledger_account_id=accounts.id)", (environment,))
        if reset_history:
            for item in state.get("items", []):
                item.setdefault("profile_cursors", {})[ACTIVE_PROFILE_ID] = None
                if ACTIVE_PROFILE_ID == "home-ledger":
                    item["cursor"] = None
            write_private_json(state_path, state)
        json_response(self, {"saved": len(rows)})

    def plaid_sync(self):
        environment, _, state_path = active_plaid_paths()
        source = f"plaid_{environment}"
        state = read_private_json(state_path)
        items = state.get("items", [])
        if not items:
            return json_response(self, {"error": f"Connect a {environment.title()} bank first."}, 400)
        imported = received = 0
        connection_errors = []
        try:
            with connect() as db:
                mappings = {r["provider_account_id"]: dict(r) for r in db.execute("SELECT m.provider_account_id,m.ledger_account_id,m.mask,m.import_transactions,a.name ledger_account,a.tracking_mode FROM bank_account_mappings m LEFT JOIN accounts a ON a.id=m.ledger_account_id WHERE m.provider='plaid' AND m.environment=? AND m.active=1", (environment,))}
                automatic_accounts = {r["id"]: r["name"] for r in db.execute("SELECT id,name FROM accounts WHERE tracking_mode='plaid_balance' AND active=1")}
                balance_totals = {account_id: 0 for account_id in automatic_accounts}
                balance_account_names = dict(automatic_accounts)
                for item in items:
                    try:
                        account_result = plaid_request("/accounts/get", {"access_token": item["access_token"]}, environment)
                    except PlaidRequestError as error:
                        item["connection_status"] = "disconnected"
                        item["connection_message"] = str(error)
                        item["connection_error_code"] = error.code
                        connection_errors.append({"accountIds": item.get("account_ids", []), "message": str(error), "code": error.code})
                        continue
                    item["connection_status"] = "connected"
                    item.pop("connection_message", None)
                    item.pop("connection_error_code", None)
                    account_types = {account.get("type") for account in account_result.get("accounts", []) if account.get("type")}
                    if not item.get("product"):
                        item["product"] = "investments" if account_types and account_types <= {"investment", "brokerage"} else "transactions"
                    for provider_account in account_result.get("accounts", []):
                        provider_account_id = provider_account.get("account_id") or ""
                        mapping = mappings.get(provider_account_id)
                        current_balance = (provider_account.get("balances") or {}).get("current")
                        display_balance = None if current_balance is None else (-abs(float(current_balance)) if provider_account.get("type") in {"credit", "loan"} else float(current_balance))
                        db.execute("UPDATE bank_account_mappings SET provider_name=?,mask=?,provider_balance=? WHERE provider='plaid' AND environment=? AND provider_account_id=?", (provider_account.get("name") or provider_account.get("official_name") or "Connected account", provider_account.get("mask") or "", display_balance, environment, provider_account_id))
                        if mapping and mapping.get("ledger_account_id") in automatic_accounts and current_balance is not None:
                            balance = display_balance
                            ledger_account_id = mapping["ledger_account_id"]
                            balance_totals[ledger_account_id] = balance_totals.get(ledger_account_id, 0) + balance
                            balance_account_names[ledger_account_id] = mapping.get("ledger_account")
                    if item.get("product", "transactions") != "transactions":
                        sync_time = datetime.now().isoformat(timespec="seconds")
                        item.setdefault("profile_last_sync", {})[ACTIVE_PROFILE_ID] = sync_time
                        if ACTIVE_PROFILE_ID == "home-ledger":
                            item["last_sync"] = sync_time
                        continue
                    profile_cursors = item.setdefault("profile_cursors", {})
                    if ACTIVE_PROFILE_ID not in profile_cursors:
                        profile_cursors[ACTIVE_PROFILE_ID] = item.get("cursor") if ACTIVE_PROFILE_ID == "home-ledger" else None
                    cursor = profile_cursors.get(ACTIVE_PROFILE_ID)
                    first_sync = not cursor
                    changes = []
                    while True:
                        request = {"access_token": item["access_token"], "count": 500}
                        if cursor:
                            request["cursor"] = cursor
                        result = plaid_request("/transactions/sync", request, environment)
                        changes.extend(result.get("added", []))
                        changes.extend(result.get("modified", []))
                        for removed in result.get("removed", []):
                            removed_id = removed.get("transaction_id") or ""
                            fingerprint_value = hashlib.sha256((f"plaid-{environment}:" + removed_id).encode()).hexdigest()
                            db.execute("DELETE FROM inbox_transactions WHERE fingerprint=?", (fingerprint_value,))
                            db.execute("DELETE FROM duplicate_reviews WHERE fingerprint=? AND status='pending'", (fingerprint_value,))
                            db.execute("DELETE FROM plaid_pending_transactions WHERE provider_transaction_id=?", (removed_id,))
                        cursor = result.get("next_cursor")
                        if not result.get("has_more"):
                            break
                    received += len(changes)
                    for transaction in changes:
                        provider_account_id = transaction.get("account_id") or ""
                        mapping = mappings.get(provider_account_id)
                        provider_id = transaction.get("transaction_id") or ""
                        description = transaction.get("merchant_name") or transaction.get("name") or "Plaid transaction"
                        amount = -float(transaction.get("amount") or 0)
                        posted_date = transaction.get("date") or datetime.now().date().isoformat()
                        transaction_date = transaction.get("authorized_date") or posted_date
                        if transaction.get("pending"):
                            db.execute("INSERT INTO plaid_pending_transactions(provider_transaction_id,provider_account_id,transaction_date,description,amount,source) VALUES(?,?,?,?,?,?) ON CONFLICT(provider_transaction_id) DO UPDATE SET transaction_date=excluded.transaction_date,description=excluded.description,amount=excluded.amount,updated_at=CURRENT_TIMESTAMP", (provider_id, provider_account_id, transaction_date, description, amount, source))
                            continue
                        if transaction.get("pending_transaction_id"):
                            db.execute("DELETE FROM plaid_pending_transactions WHERE provider_transaction_id=?", (transaction["pending_transaction_id"],))
                        if provider_account_id not in set(item.get("account_ids", [])) or not mapping or not mapping.get("ledger_account_id") or not mapping.get("import_transactions"):
                            continue
                        fingerprint_value = hashlib.sha256((f"plaid-{environment}:" + provider_id).encode()).hexdigest()
                        if db.execute("SELECT 1 FROM ignored_inbox_transactions WHERE fingerprint=?", (fingerprint_value,)).fetchone():
                            db.execute("DELETE FROM inbox_transactions WHERE fingerprint=?", (fingerprint_value,))
                            continue
                        if db.execute("SELECT 1 FROM inbox_transactions WHERE fingerprint=?", (fingerprint_value,)).fetchone():
                            db.execute("UPDATE inbox_transactions SET transaction_date=?,posted_date=?,raw_description=?,amount=?,account_id=?,card_last4=?,source_account_id=?,source=? WHERE fingerprint=?", (transaction_date, posted_date, description, amount, mapping["ledger_account_id"], mapping.get("mask") or item.get("account_masks", {}).get(provider_account_id, ""), provider_account_id, source, fingerprint_value))
                            continue
                        exact = db.execute("SELECT id FROM transactions WHERE source_fingerprint=?", (fingerprint_value,)).fetchone()
                        if exact:
                            record_decision(db, fingerprint_value, "exact_plaid_id", "Exact Plaid transaction ID already exists", exact["id"])
                            continue
                        possible = legacy_duplicate_candidates(db, mapping["ledger_account_id"], amount, transaction_date, posted_date, description)
                        if possible:
                            db.execute("DELETE FROM inbox_transactions WHERE fingerprint=?", (fingerprint_value,))
                            hold_for_review(db, fingerprint_value, transaction_date, posted_date, description, amount, mapping, provider_account_id, source, possible[0])
                            db.execute("INSERT OR IGNORE INTO import_fingerprints(fingerprint) VALUES(?)", (fingerprint_value,))
                            continue
                        db.execute("INSERT INTO inbox_transactions(fingerprint,transaction_date,posted_date,raw_description,amount,account_id,card_last4,source_account_id,source) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(fingerprint) DO UPDATE SET transaction_date=excluded.transaction_date,posted_date=excluded.posted_date,raw_description=excluded.raw_description,amount=excluded.amount,account_id=excluded.account_id,card_last4=excluded.card_last4,source_account_id=excluded.source_account_id", (fingerprint_value, transaction_date, posted_date, description, amount, mapping["ledger_account_id"], mapping.get("mask") or item.get("account_masks", {}).get(provider_account_id, ""), provider_account_id, source))
                        imported += db.execute("SELECT changes()").fetchone()[0]
                        db.execute("INSERT OR IGNORE INTO import_fingerprints(fingerprint) VALUES(?)", (fingerprint_value,))
                    profile_cursors[ACTIVE_PROFILE_ID] = cursor
                    sync_time = datetime.now().isoformat(timespec="seconds")
                    item.setdefault("profile_last_sync", {})[ACTIVE_PROFILE_ID] = sync_time
                    if ACTIVE_PROFILE_ID == "home-ledger":
                        item["cursor"] = cursor
                        item["last_sync"] = sync_time
                for ledger_account_id, total_balance in balance_totals.items():
                    if balance_account_names.get(ledger_account_id) == "Mortgage":
                        total_balance -= MORTGAGE_FORBEARANCE_BALANCE
                    db.execute("UPDATE accounts SET current_balance=? WHERE id=?", (total_balance, ledger_account_id))
        except ValueError as error:
            return json_response(self, {"error": str(error)}, 400)
        write_private_json(state_path, state)
        json_response(self, {"added": imported, "received": received, "connectionErrors": connection_errors, "lastSync": max((item.get("profile_last_sync") or {}).get(ACTIVE_PROFILE_ID, "") for item in items)})

    def clear_plaid_sandbox(self):
        with connect() as db:
            count = db.execute("SELECT COUNT(*) FROM sandbox_transactions").fetchone()[0]
            promoted = list(db.execute("SELECT t.id,t.amount,c.name category,a.id account_id,a.tracking_mode FROM sandbox_transactions s JOIN transactions t ON t.id=s.promoted_transaction_id LEFT JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id"))
            for row in promoted:
                if row["tracking_mode"] == "transaction_derived":
                    db.execute("UPDATE accounts SET current_balance=current_balance-? WHERE id=?", (row["amount"], row["account_id"]))
                db.execute("UPDATE funds SET balance=balance-? WHERE name=?", (row["amount"], row["category"]))
                db.execute("UPDATE sandbox_transactions SET promoted_transaction_id=NULL WHERE promoted_transaction_id=?", (row["id"],))
                db.execute("DELETE FROM transactions WHERE id=?", (row["id"],))
            db.execute("DELETE FROM sandbox_transactions")
        json_response(self, {"deleted": count, "reversed": len(promoted)})

    def submit_plaid_sandbox(self, payload):
        submitted_rows = {int(row["id"]): row for row in payload.get("rows", []) if str(row.get("id", "")).isdigit()}
        with connect() as db:
            category_ids = {r["name"]: r["id"] for r in valid_category_rows(db)}
            sandbox_rows = list(db.execute("SELECT s.*,m.ledger_account_id,a.tracking_mode FROM sandbox_transactions s LEFT JOIN bank_account_mappings m ON m.provider='plaid' AND m.environment='sandbox' AND m.provider_account_id=s.provider_account_id LEFT JOIN accounts a ON a.id=m.ledger_account_id WHERE s.promoted_transaction_id IS NULL ORDER BY s.id"))
            if not sandbox_rows:
                return json_response(self, {"error": "There are no unsubmitted Sandbox transactions."}, 400)
            for row in sandbox_rows:
                submitted = submitted_rows.get(row["id"], {})
                description = (submitted.get("description") or "").strip()
                category = submitted.get("category") or ""
                if not description or category not in category_ids or not row["ledger_account_id"]:
                    return json_response(self, {"error": "Every Sandbox transaction needs a description, category, and mapped account."}, 400)
            for row in sandbox_rows:
                submitted = submitted_rows[row["id"]]
                description = submitted["description"].strip()
                category = submitted["category"]
                cursor = db.execute("INSERT INTO transactions(transaction_date,raw_description,description,category_id,amount,account_id,source) VALUES(?,?,?,?,?,?,'sandbox_test')", (row["transaction_date"], row["description"], description, category_ids[category], row["amount"], row["ledger_account_id"]))
                transaction_id = cursor.lastrowid
                db.execute("UPDATE sandbox_transactions SET user_description=?,category_id=?,promoted_transaction_id=? WHERE id=?", (description, category_ids[category], transaction_id, row["id"]))
                if row["tracking_mode"] == "transaction_derived":
                    db.execute("UPDATE accounts SET current_balance=current_balance+? WHERE id=?", (row["amount"], row["ledger_account_id"]))
                db.execute("UPDATE funds SET balance=balance+? WHERE name=?", (row["amount"], category))
        json_response(self, {"submitted": len(sandbox_rows)})

    def bootstrap(self, query):
        run_monthly_rollover()
        run_recurring_transactions()
        with connect() as db:
            current_month = datetime.now().strftime("%Y-%m")
            mortgage_date = current_month + "-01"
            mortgage_row = db.execute("SELECT principal_balance FROM mortgage_schedule WHERE payment_date<=? ORDER BY payment_date DESC LIMIT 1", (mortgage_date,)).fetchone()
            if mortgage_row:
                db.execute("UPDATE accounts SET current_balance=? WHERE name='Mortgage' AND tracking_mode='amortization_derived'", (-(mortgage_row["principal_balance"] + 10559.64),))
            car_loan_row = db.execute("SELECT principal_balance FROM car_loan_schedule WHERE payment_date<=? ORDER BY payment_date DESC LIMIT 1", (mortgage_date,)).fetchone()
            if car_loan_row:
                db.execute("UPDATE accounts SET current_balance=? WHERE name='Car Loan' AND tracking_mode='amortization_derived'", (-car_loan_row["principal_balance"],))
            if query.get("month"):
                month = query["month"][0]
            else:
                month = current_month
            start = month + "-01"
            end = (datetime.strptime(start, "%Y-%m-%d") + timedelta(days=32)).replace(day=1).date().isoformat()
            saved_months = [r["month"] for r in db.execute("SELECT month FROM budget_periods ORDER BY month DESC")]
            previous_month = (datetime.strptime(current_month + "-01", "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m")
            transaction_months = [r["month"] for r in db.execute("SELECT DISTINCT substr(transaction_date,1,7) month FROM transactions WHERE transaction_date<? ORDER BY month DESC", (current_month + "-01",))]
            available_past_months = sorted({previous_month, *(value for value in saved_months if value < current_month), *transaction_months}, reverse=True)
            plan_source_month = month if month in saved_months else db.execute("SELECT MAX(month) FROM budget_periods WHERE month < ?", (month,)).fetchone()[0]
            if plan_source_month is None and saved_months:
                plan_source_month = saved_months[-1]
            categories = [r["name"] for r in valid_category_rows(db)]
            descriptions = [dict(r) for r in db.execute("SELECT description,COUNT(*) uses FROM transactions GROUP BY description ORDER BY uses DESC,description LIMIT 250")]
            budget = []
            if plan_source_month:
                budget = [dict(r) for r in db.execute("SELECT c.name category,bl.planned_amount planned,c.kind,COALESCE(CASE WHEN c.kind='income' THEN SUM(t.amount) ELSE -SUM(t.amount) END,0) actual FROM budget_periods bp JOIN budget_lines bl ON bl.period_id=bp.id JOIN categories c ON c.id=bl.category_id LEFT JOIN transactions t ON t.category_id=c.id AND t.source<>'fund_adjustment' AND t.transaction_date>=? AND t.transaction_date<? WHERE bp.month=? GROUP BY c.id,bl.planned_amount,bl.sort_order ORDER BY CASE WHEN c.kind='income' THEN 0 ELSE 1 END,COALESCE(bl.sort_order,100000),c.name", (start, end, plan_source_month))]
            accounts = [dict(r) for r in db.execute("SELECT id,name,current_balance,tracking_mode,sort_order FROM accounts WHERE active=1 ORDER BY COALESCE(sort_order,100000),name COLLATE NOCASE")]
            net_worth = sum(r["current_balance"] for r in accounts)
            funds = [dict(r) for r in db.execute("SELECT f.id,f.name,f.starting_balance, f.starting_balance+COALESCE(SUM(t.amount),0) balance FROM funds f LEFT JOIN categories c ON c.name=f.name LEFT JOIN transactions t ON t.category_id=c.id GROUP BY f.id,f.name,f.starting_balance,f.sort_order ORDER BY COALESCE(f.sort_order,100000),f.name")]
            stats = dict(db.execute("SELECT (SELECT COUNT(*) FROM transactions) transactions,(SELECT COUNT(*) FROM inbox_transactions) inbox,(SELECT COUNT(*) FROM budget_periods) months").fetchone())
        json_response(self, {"categories": categories, "descriptions": descriptions, "budget": budget, "accounts": accounts, "netWorth": net_worth, "funds": funds, "stats": stats, "month": month, "currentMonth": current_month, "savedBudgetMonths": saved_months, "availablePastMonths": available_past_months, "planSourceMonth": plan_source_month})

    def inbox(self):
        with connect() as db:
            rows = [dict(r) for r in db.execute("SELECT i.id,i.transaction_date transactionDate,i.posted_date postedDate,i.raw_description rawDescription,i.description,c.name category,i.amount,a.name account FROM inbox_transactions i LEFT JOIN categories c ON c.id=i.category_id LEFT JOIN accounts a ON a.id=i.account_id ORDER BY i.transaction_date DESC,i.id DESC")]
        json_response(self, rows)

    def duplicate_reviews(self):
        with connect() as db:
            rows = [dict(r) for r in db.execute("SELECT d.id,d.transaction_date transactionDate,d.raw_description rawDescription,d.amount,a.name account,d.reason,t.transaction_date matchDate,COALESCE(t.raw_description,t.description) matchDescription,t.amount matchAmount FROM duplicate_reviews d LEFT JOIN accounts a ON a.id=d.account_id LEFT JOIN transactions t ON t.id=d.matched_transaction_id WHERE d.status='pending' ORDER BY d.transaction_date DESC,d.id DESC")]
        json_response(self, rows)

    def resolve_duplicate(self, payload, keep):
        try:
            duplicate_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a possible duplicate."}, 400)
        with connect() as db:
            row = db.execute("SELECT * FROM duplicate_reviews WHERE id=? AND status='pending'", (duplicate_id,)).fetchone()
            if not row:
                return json_response(self, {"error": "That possible duplicate was already resolved."}, 404)
            resolve_review(db, row, keep)
        json_response(self, {"resolved": True, "kept": keep})

    def budget_setup(self, query):
        run_monthly_rollover()
        month = query.get("month", [datetime.now().strftime("%Y-%m")])[0]
        if not re.fullmatch(r"\d{4}-\d{2}", month):
            return json_response(self, {"error": "Choose a valid budget month."}, 400)
        with connect() as db:
            rows = [dict(r) for r in db.execute("SELECT c.id categoryId,c.name,c.kind,bl.planned_amount planned FROM budget_periods bp JOIN budget_lines bl ON bl.period_id=bp.id JOIN categories c ON c.id=bl.category_id WHERE bp.month=? ORDER BY CASE WHEN c.kind='income' THEN 0 ELSE 1 END,COALESCE(bl.sort_order,100000),c.name", (month,))]
        json_response(self, {"month": month, "rows": rows})

    def save_budget_setup(self, payload):
        run_monthly_rollover()
        month = payload.get("month") or datetime.now().strftime("%Y-%m")
        if not re.fullmatch(r"\d{4}-\d{2}", month):
            return json_response(self, {"error": "Choose a valid budget month."}, 400)
        rows = payload.get("rows", [])
        if not isinstance(rows, list) or not rows:
            return json_response(self, {"error": "Keep at least one line in the current budget."}, 400)
        cleaned, seen_names = [], set()
        for row in rows:
            name = (row.get("name") or "").strip()
            kind = row.get("kind") if row.get("kind") in {"income", "spending"} else "spending"
            try:
                planned = round(float(row.get("planned", 0)), 2)
            except (TypeError, ValueError):
                return json_response(self, {"error": f"Enter a valid planned amount for {name or 'each category'}."}, 400)
            if not name:
                return json_response(self, {"error": "Every budget line needs a category name."}, 400)
            if planned < 0:
                return json_response(self, {"error": f"The planned amount for {name} cannot be negative."}, 400)
            key = name.casefold()
            if key in seen_names:
                return json_response(self, {"error": f"{name} appears more than once in the budget."}, 400)
            seen_names.add(key)
            cleaned.append({"categoryId": row.get("categoryId"), "name": name, "kind": kind, "planned": planned})
        with connect() as db:
            for row in cleaned:
                if db.execute("SELECT 1 FROM funds WHERE name=? COLLATE NOCASE", (row["name"],)).fetchone():
                    return json_response(self, {"error": f"The name {row['name']} is already used by a Running Fund. Income, spending, and Running Fund category names must be unique."}, 400)
            status = "current" if month == datetime.now().strftime("%Y-%m") else "closed"
            db.execute("INSERT OR IGNORE INTO budget_periods(month,status) VALUES(?,?)", (month, status))
            period_id = db.execute("SELECT id FROM budget_periods WHERE month=?", (month,)).fetchone()[0]
            category_ids = []
            for row in cleaned:
                category = None
                if row["categoryId"] is not None:
                    category = db.execute("SELECT id,name FROM categories WHERE id=?", (row["categoryId"],)).fetchone()
                    if category and category["name"] != row["name"]:
                        duplicate = db.execute("SELECT id FROM categories WHERE name=? COLLATE NOCASE AND id<>?", (row["name"], category["id"])).fetchone()
                        if duplicate:
                            return json_response(self, {"error": f"A category named {row['name']} already exists."}, 400)
                        old_fund = db.execute("SELECT 1 FROM funds WHERE name=?", (category["name"],)).fetchone()
                        if old_fund and db.execute("SELECT 1 FROM funds WHERE name=? COLLATE NOCASE AND name<>?", (row["name"], category["name"])).fetchone():
                            return json_response(self, {"error": f"A Running Fund named {row['name']} already exists."}, 400)
                        db.execute("UPDATE categories SET name=? WHERE id=?", (row["name"], category["id"]))
                        if old_fund:
                            db.execute("UPDATE funds SET name=? WHERE name=?", (row["name"], category["name"]))
                        category = db.execute("SELECT id,name FROM categories WHERE id=?", (category["id"],)).fetchone()
                if not category:
                    category = db.execute("SELECT id,name FROM categories WHERE name=? COLLATE NOCASE", (row["name"],)).fetchone()
                if category:
                    category_id = category["id"]
                    db.execute("UPDATE categories SET active=1,kind=? WHERE id=?", (row["kind"], category_id))
                else:
                    category_id = db.execute("INSERT INTO categories(name,kind) VALUES(?,?)", (row["name"], row["kind"])).lastrowid
                category_ids.append((category_id, row["planned"]))
            db.execute("DELETE FROM budget_lines WHERE period_id=?", (period_id,))
            db.executemany("INSERT INTO budget_lines(period_id,category_id,planned_amount,sort_order) VALUES(?,?,?,?)", ((period_id, category_id, planned, position) for position, (category_id, planned) in enumerate(category_ids)))
        json_response(self, {"saved": len(cleaned), "month": month})

    def transactions(self, query):
        page = max(1, int(query.get("page", ["1"])[0]))
        month = query.get("month", [""])[0].strip()
        search = query.get("q", [""])[0].strip()
        where, params = [], []
        if month:
            start = month + "-01"
            end = (datetime.strptime(start, "%Y-%m-%d") + timedelta(days=32)).replace(day=1).date().isoformat()
            where.append("t.transaction_date>=? AND t.transaction_date<?")
            params.extend([start, end])
        if search:
            where.append("(t.description LIKE ? OR COALESCE(t.raw_description,'') LIKE ? OR c.name LIKE ? OR a.name LIKE ?)")
            like = f"%{search}%"
            params.extend([like, like, like, like])
        clause = " WHERE " + " AND ".join(where) if where else ""
        with connect() as db:
            total = db.execute("SELECT COUNT(*) FROM transactions t LEFT JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id" + clause, params).fetchone()[0]
            rows = [dict(r) for r in db.execute("SELECT t.id,t.transaction_date transactionDate,t.description,COALESCE(t.raw_description,'') rawDescription,c.name category,a.name account,t.amount,t.source FROM transactions t LEFT JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id" + clause + " ORDER BY t.transaction_date DESC,t.id DESC LIMIT 200 OFFSET ?", (*params, (page - 1) * 200))]
        json_response(self, {"rows": rows, "total": total, "page": page, "pages": max(1, (total + 199) // 200)})

    def transfer_templates(self):
        with connect() as db:
            rows = [dict(row) for row in db.execute("SELECT t.id,t.name,fc.name fromCategory,tc.name toCategory,fa.name fromAccount,ta.name toAccount FROM transfer_templates t JOIN categories fc ON fc.id=t.from_category_id JOIN categories tc ON tc.id=t.to_category_id LEFT JOIN accounts fa ON fa.id=t.from_account_id LEFT JOIN accounts ta ON ta.id=t.to_account_id ORDER BY t.name,t.id")]
        json_response(self, {"rows": rows})

    def create_transfer_template(self, payload):
        name = (payload.get("name") or "").strip()
        from_category, to_category = (payload.get("fromCategory") or "").strip(), (payload.get("toCategory") or "").strip()
        from_account, to_account = (payload.get("fromAccount") or "").strip(), (payload.get("toAccount") or "").strip()
        if not name:
            return json_response(self, {"error": "Enter a template name."}, 400)
        with connect() as db:
            categories = {row["name"]: row["id"] for row in valid_category_rows(db)}
            accounts = {row["name"]: row["id"] for row in db.execute("SELECT id,name FROM accounts WHERE active=1")}
            if from_category not in categories or to_category not in categories or from_category == to_category:
                return json_response(self, {"error": "Choose two different valid categories."}, 400)
            if (from_account and from_account not in accounts) or (to_account and to_account not in accounts):
                return json_response(self, {"error": "Choose valid accounts or leave them blank."}, 400)
            template_id = db.execute("INSERT INTO transfer_templates(name,from_category_id,to_category_id,from_account_id,to_account_id) VALUES(?,?,?,?,?)", (name, categories[from_category], categories[to_category], accounts.get(from_account), accounts.get(to_account))).lastrowid
        json_response(self, {"created": True, "id": template_id})

    def delete_transfer_template(self, payload):
        try:
            template_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid transfer template."}, 400)
        with connect() as db:
            template = db.execute("SELECT name FROM transfer_templates WHERE id=?", (template_id,)).fetchone()
            if not template:
                return json_response(self, {"error": "Transfer template not found."}, 404)
            db.execute("DELETE FROM transfer_templates WHERE id=?", (template_id,))
        json_response(self, {"deleted": True, "name": template["name"]})

    def recurring_transactions(self):
        run_recurring_transactions()
        with connect() as db:
            rows = [dict(row) for row in db.execute("SELECT r.id,r.description,c.name category,r.amount,a.name account,r.frequency,r.start_date startDate,r.next_date nextDate FROM recurring_transactions r JOIN categories c ON c.id=r.category_id LEFT JOIN accounts a ON a.id=r.account_id WHERE r.active=1 ORDER BY r.next_date,r.id")]
        json_response(self, {"rows": rows})

    def create_recurring_transaction(self, payload):
        description = (payload.get("description") or "").strip()
        category = (payload.get("category") or "").strip()
        account = (payload.get("account") or "").strip()
        frequency = (payload.get("frequency") or "").strip()
        start_date = (payload.get("startDate") or "").strip()
        if not description:
            return json_response(self, {"error": "Enter a description."}, 400)
        if frequency not in {"daily", "weekly", "biweekly", "monthly", "quarterly", "yearly"}:
            return json_response(self, {"error": "Choose a valid frequency."}, 400)
        try:
            parsed_start = None
            for date_format in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
                try:
                    parsed_start = datetime.strptime(start_date, date_format).date().isoformat()
                    break
                except ValueError:
                    pass
            if not parsed_start:
                raise ValueError
            amount = float(str(payload.get("amount", "")).replace("$", "").replace(",", ""))
        except ValueError:
            return json_response(self, {"error": "Enter a valid first date and amount."}, 400)
        if not math.isfinite(amount):
            return json_response(self, {"error": "Enter a valid amount."}, 400)
        with connect() as db:
            categories = {row["name"]: row["id"] for row in valid_category_rows(db)}
            accounts = {row["name"]: row["id"] for row in db.execute("SELECT id,name FROM accounts WHERE active=1")}
            if category not in categories:
                return json_response(self, {"error": "Choose a valid category for this budget."}, 400)
            if account and account not in accounts:
                return json_response(self, {"error": "Choose a valid account."}, 400)
            rule_id = db.execute("INSERT INTO recurring_transactions(description,category_id,amount,account_id,frequency,start_date,next_date) VALUES(?,?,?,?,?,?,?)", (description, categories[category], amount, accounts.get(account), frequency, parsed_start, parsed_start)).lastrowid
        run_recurring_transactions()
        json_response(self, {"created": True, "id": rule_id})

    def delete_recurring_transaction(self, payload):
        try:
            rule_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid recurring transaction."}, 400)
        with connect() as db:
            rule = db.execute("SELECT description FROM recurring_transactions WHERE id=? AND active=1", (rule_id,)).fetchone()
            if not rule:
                return json_response(self, {"error": "Recurring transaction not found."}, 404)
            db.execute("UPDATE recurring_transactions SET active=0 WHERE id=?", (rule_id,))
        json_response(self, {"stopped": True, "description": rule["description"]})

    def update_recurring_transaction(self, payload):
        try:
            rule_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid recurring transaction."}, 400)
        description = (payload.get("description") or "").strip()
        category = (payload.get("category") or "").strip()
        account = (payload.get("account") or "").strip()
        frequency = (payload.get("frequency") or "").strip()
        start_date = (payload.get("startDate") or "").strip()
        if not description:
            return json_response(self, {"error": "Enter a description."}, 400)
        if frequency not in {"daily", "weekly", "biweekly", "monthly", "quarterly", "yearly"}:
            return json_response(self, {"error": "Choose a valid frequency."}, 400)
        try:
            parsed_start = None
            for date_format in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
                try:
                    parsed_start = datetime.strptime(start_date, date_format).date().isoformat()
                    break
                except ValueError:
                    pass
            if not parsed_start:
                raise ValueError
            amount = float(str(payload.get("amount", "")).replace("$", "").replace(",", ""))
        except ValueError:
            return json_response(self, {"error": "Enter a valid schedule date and amount."}, 400)
        if not math.isfinite(amount):
            return json_response(self, {"error": "Enter a valid amount."}, 400)
        next_date = parsed_start
        today = datetime.now().date().isoformat()
        while next_date <= today:
            next_date = next_recurring_date(next_date, frequency, parsed_start)
        with connect() as db:
            categories = {row["name"]: row["id"] for row in valid_category_rows(db)}
            accounts = {row["name"]: row["id"] for row in db.execute("SELECT id,name FROM accounts WHERE active=1")}
            if category not in categories:
                return json_response(self, {"error": "Choose a valid category for this budget."}, 400)
            if account and account not in accounts:
                return json_response(self, {"error": "Choose a valid account."}, 400)
            if not db.execute("SELECT 1 FROM recurring_transactions WHERE id=? AND active=1", (rule_id,)).fetchone():
                return json_response(self, {"error": "Recurring transaction not found."}, 404)
            db.execute("UPDATE recurring_transactions SET description=?,category_id=?,amount=?,account_id=?,frequency=?,start_date=?,next_date=? WHERE id=?", (description, categories[category], amount, accounts.get(account), frequency, parsed_start, next_date, rule_id))
        json_response(self, {"updated": True, "id": rule_id, "nextDate": next_date})

    def budget_transactions(self, query):
        month = query.get("month", [""])[0]
        category = query.get("category", [""])[0]
        try:
            start = datetime.strptime(month + "-01", "%Y-%m-%d")
        except ValueError:
            return json_response(self, {"error": "Invalid budget month."}, 400)
        end = (start + timedelta(days=32)).replace(day=1).date().isoformat()
        with connect() as db:
            rows = [dict(r) for r in db.execute("SELECT t.id,t.transaction_date transactionDate,t.description,c.name category,a.name account,t.amount FROM transactions t JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id WHERE c.name=? AND t.source<>'fund_adjustment' AND t.transaction_date>=? AND t.transaction_date<? ORDER BY t.transaction_date,t.id", (category, start.date().isoformat(), end))]
        json_response(self, {"rows": rows, "count": len(rows)})

    def fund_transactions(self, query):
        category = query.get("category", [""])[0].strip()
        with connect() as db:
            is_fund = db.execute("SELECT 1 FROM funds WHERE name=?", (category,)).fetchone()
            if not is_fund:
                return json_response(self, {"error": "Running fund not found."}, 404)
            rows = [dict(r) for r in db.execute("SELECT t.id,t.transaction_date transactionDate,t.description,c.name category,a.name account,t.amount FROM transactions t JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id WHERE c.name=? ORDER BY t.transaction_date DESC,t.id DESC", (category,))]
        json_response(self, {"rows": rows, "count": len(rows)})

    def create_fund(self, payload):
        name = (payload.get("name") or "").strip()
        if not name:
            return json_response(self, {"error": "Enter a running fund name."}, 400)
        try:
            starting_balance = float(str(payload.get("startingBalance", "0")).replace("$", "").replace(",", ""))
        except ValueError:
            return json_response(self, {"error": "Enter a valid starting balance."}, 400)
        if not math.isfinite(starting_balance):
            return json_response(self, {"error": "Enter a valid starting balance."}, 400)
        with connect() as db:
            if db.execute("SELECT 1 FROM funds WHERE name=? COLLATE NOCASE", (name,)).fetchone():
                return json_response(self, {"error": f"A running fund named {name} already exists."}, 400)
            category = db.execute("SELECT id,name FROM categories WHERE name=? COLLATE NOCASE", (name,)).fetchone()
            if category:
                return json_response(self, {"error": f"The name {category['name']} is already used by an income or spending category. Choose a different Running Fund name."}, 400)
            category_id = db.execute("INSERT INTO categories(name,kind) VALUES(?,'spending')", (name,)).lastrowid
            category = {"id": category_id, "name": name}
            next_order = db.execute("SELECT COALESCE(MAX(sort_order),-1)+1 FROM funds").fetchone()[0]
            db.execute("INSERT INTO funds(name,starting_balance,balance,sort_order) VALUES(?,0,0,?)", (name, next_order))
            if abs(starting_balance) > 0.004:
                db.execute("INSERT INTO transactions(transaction_date,description,category_id,amount,source) VALUES(date('now'),'Starting balance',?,?,'fund_adjustment')", (category["id"], starting_balance))
        json_response(self, {"created": True, "name": name, "startingBalance": starting_balance})

    def adjust_fund(self, payload):
        name = (payload.get("name") or "").strip()
        try:
            target = float(str(payload.get("balance", "")).replace("$", "").replace(",", ""))
        except ValueError:
            return json_response(self, {"error": "Enter a valid new balance."}, 400)
        if not math.isfinite(target):
            return json_response(self, {"error": "Enter a valid new balance."}, 400)
        with connect() as db:
            fund = db.execute("SELECT f.name,c.id category_id,COALESCE(SUM(t.amount),0) current_balance FROM funds f JOIN categories c ON c.name=f.name LEFT JOIN transactions t ON t.category_id=c.id WHERE f.name=? GROUP BY f.id,c.id", (name,)).fetchone()
            if not fund:
                return json_response(self, {"error": "Running fund not found."}, 404)
            difference = target - fund["current_balance"]
            if abs(difference) > 0.004:
                db.execute("INSERT INTO transactions(transaction_date,description,category_id,amount,source) VALUES(date('now'),'Balance adjustment',?,?,'fund_adjustment')", (fund["category_id"], difference))
        json_response(self, {"adjusted": abs(difference) > 0.004, "name": fund["name"], "previousBalance": fund["current_balance"], "newBalance": target, "difference": difference})

    def rename_fund(self, payload):
        try:
            fund_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid running fund."}, 400)
        name = (payload.get("name") or "").strip()
        if not name:
            return json_response(self, {"error": "Enter a running fund name."}, 400)
        with connect() as db:
            fund = db.execute("SELECT id,name FROM funds WHERE id=?", (fund_id,)).fetchone()
            if not fund:
                return json_response(self, {"error": "Running fund not found."}, 404)
            if db.execute("SELECT 1 FROM funds WHERE name=? COLLATE NOCASE AND id<>?", (name, fund_id)).fetchone():
                return json_response(self, {"error": f"A running fund named {name} already exists."}, 400)
            category = db.execute("SELECT id FROM categories WHERE name=?", (fund["name"],)).fetchone()
            duplicate_category = db.execute("SELECT id FROM categories WHERE name=? COLLATE NOCASE AND name<>?", (name, fund["name"])).fetchone()
            if duplicate_category and (not category or duplicate_category["id"] != category["id"]):
                return json_response(self, {"error": f"A category named {name} already exists."}, 400)
            if category:
                db.execute("UPDATE categories SET name=? WHERE id=?", (name, category["id"]))
            db.execute("UPDATE funds SET name=? WHERE id=?", (name, fund_id))
        json_response(self, {"renamed": True, "id": fund_id, "name": name})

    def delete_fund(self, payload):
        try:
            fund_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid running fund."}, 400)
        with connect() as db:
            fund = db.execute("SELECT name FROM funds WHERE id=?", (fund_id,)).fetchone()
            if not fund:
                return json_response(self, {"error": "Running fund not found."}, 404)
            db.execute("DELETE FROM funds WHERE id=?", (fund_id,))
        json_response(self, {"deleted": True, "name": fund["name"]})

    def reorder_funds(self, payload):
        ids = []
        for value in payload.get("ids", []):
            try:
                ids.append(int(value))
            except (TypeError, ValueError):
                continue
        with connect() as db:
            existing = {row["id"] for row in db.execute("SELECT id FROM funds")}
            if not ids or len(ids) != len(set(ids)) or set(ids) != existing:
                return json_response(self, {"error": "The running fund order was not valid."}, 400)
            db.executemany("UPDATE funds SET sort_order=? WHERE id=?", ((position, fund_id) for position, fund_id in enumerate(ids)))
        json_response(self, {"saved": len(ids)})

    def account_plaid_transactions(self, query):
        try:
            account_id = int((query.get("accountId") or [""])[0])
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid account."}, 400)
        with connect() as db:
            account = db.execute("SELECT id,name FROM accounts WHERE id=? AND active=1", (account_id,)).fetchone()
            if not account:
                return json_response(self, {"error": "That account is no longer available."}, 404)
            rows = [dict(row) for row in db.execute(
                """
                SELECT t.transaction_date transactionDate,
                       COALESCE(NULLIF(t.description,''),t.raw_description) description,
                       c.name category,t.amount,'Reviewed' status
                FROM transactions t
                LEFT JOIN categories c ON c.id=t.category_id
                WHERE t.account_id=? AND t.source IN ('plaid_production','plaid_sandbox')
                UNION ALL
                SELECT i.transaction_date,
                       COALESCE(NULLIF(i.description,''),i.raw_description),
                       c.name,i.amount,'Review inbox'
                FROM inbox_transactions i
                LEFT JOIN categories c ON c.id=i.category_id
                WHERE i.account_id=? AND i.source IN ('plaid_production','plaid_sandbox')
                ORDER BY transactionDate DESC
                """, (account_id, account_id)
            )]
        json_response(self, {"account": account["name"], "rows": rows, "count": len(rows)})

    def save_transactions(self, payload):
        rows = payload.get("rows", [])
        with connect() as db:
            category_ids = {r["name"]: r["id"] for r in valid_category_rows(db)}
            account_rows = {r["name"]: dict(r) for r in db.execute("SELECT id,name,tracking_mode FROM accounts WHERE active=1")}
            for row in rows:
                is_new = bool(row.get("isNew"))
                old = None if is_new else db.execute("SELECT t.amount,c.name category,a.tracking_mode,a.id account_id FROM transactions t LEFT JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id WHERE t.id=?", (row["id"],)).fetchone()
                description = (row.get("description") or "").strip()
                category = row.get("category") or ""
                try:
                    amount = float(str(row.get("amount", "")).replace("$", "").replace(",", ""))
                except ValueError:
                    return json_response(self, {"error": "Every changed transaction needs a valid amount."}, 400)
                if not math.isfinite(amount):
                    return json_response(self, {"error": "Every changed transaction needs a valid amount."}, 400)
                entered_date = (row.get("transactionDate") or "").strip()
                parsed_date = None
                for date_format in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
                    try:
                        parsed_date = datetime.strptime(entered_date, date_format).date().isoformat()
                        break
                    except ValueError:
                        continue
                if parsed_date is None:
                    return json_response(self, {"error": "Every changed transaction needs a valid date."}, 400)
                if not description or category not in category_ids:
                    return json_response(self, {"error": "Every changed transaction needs a description and valid category."}, 400)
                if is_new:
                    account = account_rows.get(row.get("account") or "")
                    if row.get("account") and not account:
                        return json_response(self, {"error": "Choose a valid account or leave it blank."}, 400)
                    db.execute("INSERT INTO transactions(transaction_date,description,category_id,amount,account_id,source) VALUES(?,?,?,?,?,'manual')", (parsed_date, description, category_ids[category], amount, account["id"] if account else None))
                    db.execute("UPDATE funds SET balance=balance+? WHERE name=?", (amount, category))
                    if account and account["tracking_mode"] == "transaction_derived":
                        db.execute("UPDATE accounts SET current_balance=current_balance+? WHERE id=?", (amount, account["id"]))
                else:
                    account_name = (row.get("account") or "").strip()
                    account = account_rows.get(account_name) if account_name else None
                    if account_name and not account:
                        return json_response(self, {"error": "Choose a valid account or leave it blank."}, 400)
                    if not old:
                        return json_response(self, {"error": "That transaction no longer exists."}, 404)
                    db.execute("UPDATE transactions SET transaction_date=?,description=?,category_id=?,amount=?,account_id=? WHERE id=?", (parsed_date, description, category_ids[category], amount, account["id"] if account else None, row["id"]))
                    if old:
                        db.execute("UPDATE funds SET balance=balance-? WHERE name=?", (old["amount"], old["category"]))
                    db.execute("UPDATE funds SET balance=balance+? WHERE name=?", (amount, category))
                    if old["tracking_mode"] == "transaction_derived":
                        db.execute("UPDATE accounts SET current_balance=current_balance-? WHERE id=?", (old["amount"], old["account_id"]))
                    if account and account["tracking_mode"] == "transaction_derived":
                        db.execute("UPDATE accounts SET current_balance=current_balance+? WHERE id=?", (amount, account["id"]))
        json_response(self, {"saved": len(rows)})

    def create_internal_transfer(self, payload):
        rows = payload.get("rows", [])
        if not isinstance(rows, list) or len(rows) != 2:
            return json_response(self, {"error": "An internal transfer requires exactly two transactions."}, 400)
        with connect() as db:
            category_ids = {row["name"]: row["id"] for row in valid_category_rows(db)}
            accounts = {row["name"]: dict(row) for row in db.execute("SELECT id,name,tracking_mode FROM accounts WHERE active=1")}
            cleaned = []
            for row in rows:
                entered_date = (row.get("transactionDate") or "").strip()
                parsed_date = None
                for date_format in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
                    try:
                        parsed_date = datetime.strptime(entered_date, date_format).date().isoformat()
                        break
                    except ValueError:
                        continue
                description, category, account_name = (row.get("description") or "").strip(), (row.get("category") or "").strip(), (row.get("account") or "").strip()
                try:
                    amount = float(str(row.get("amount", "")).replace("$", "").replace(",", ""))
                except ValueError:
                    amount = math.nan
                account = accounts.get(account_name) if account_name else None
                if parsed_date is None or not description or category not in category_ids or not math.isfinite(amount) or (account_name and not account):
                    return json_response(self, {"error": "Both transfer transactions need valid dates, descriptions, categories, amounts, and optional accounts."}, 400)
                cleaned.append((parsed_date, description, category, category_ids[category], amount, account))
            if cleaned[0][2] == cleaned[1][2] or cleaned[0][4] >= 0 or cleaned[1][4] <= 0 or abs(cleaned[0][4] + cleaned[1][4]) >= .005:
                return json_response(self, {"error": "A transfer must move equal amounts between two different categories."}, 400)
            for transaction_date, description, category, category_id, amount, account in cleaned:
                db.execute("INSERT INTO transactions(transaction_date,description,category_id,amount,account_id,source) VALUES(?,?,?,?,?,'internal_transfer')", (transaction_date, description, category_id, amount, account["id"] if account else None))
                db.execute("UPDATE funds SET balance=balance+? WHERE name=?", (amount, category))
                if account and account["tracking_mode"] == "transaction_derived":
                    db.execute("UPDATE accounts SET current_balance=current_balance+? WHERE id=?", (amount, account["id"]))
        json_response(self, {"saved": 2})

    def split_transaction(self, payload):
        try:
            transaction_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid transaction to split."}, 400)
        rows = payload.get("rows", [])
        if not isinstance(rows, list) or len(rows) < 2:
            return json_response(self, {"error": "A split needs at least two lines."}, 400)
        with connect() as db:
            original = db.execute("SELECT t.*,c.name category,a.tracking_mode FROM transactions t LEFT JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id WHERE t.id=?", (transaction_id,)).fetchone()
            if not original:
                return json_response(self, {"error": "That transaction no longer exists."}, 404)
            category_ids = {row["name"]: row["id"] for row in valid_category_rows(db)}
            accounts = {row["name"]: dict(row) for row in db.execute("SELECT id,name,tracking_mode FROM accounts WHERE active=1")}
            cleaned = []
            for row in rows:
                entered_date = (row.get("transactionDate") or "").strip()
                parsed_date = None
                for date_format in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
                    try:
                        parsed_date = datetime.strptime(entered_date, date_format).date().isoformat()
                        break
                    except ValueError:
                        continue
                if parsed_date is None:
                    return json_response(self, {"error": "Every split line needs a valid date."}, 400)
                description = (row.get("description") or "").strip()
                category = (row.get("category") or "").strip()
                account_name = (row.get("account") or "").strip()
                try:
                    amount = float(str(row.get("amount", "")).replace("$", "").replace(",", ""))
                except ValueError:
                    return json_response(self, {"error": "Every split line needs a valid amount."}, 400)
                if not math.isfinite(amount) or not description or category not in category_ids:
                    return json_response(self, {"error": "Every split line needs a description, valid category, and valid amount."}, 400)
                account = accounts.get(account_name) if account_name else None
                if account_name and not account:
                    return json_response(self, {"error": "Choose a valid account or leave it blank."}, 400)
                cleaned.append((parsed_date, description, category, category_ids[category], amount, account))
            if abs(sum(row[4] for row in cleaned) - original["amount"]) >= .005:
                return json_response(self, {"error": "The split amounts must add up to the original transaction amount."}, 400)
            db.execute("UPDATE funds SET balance=balance-? WHERE name=?", (original["amount"], original["category"]))
            if original["tracking_mode"] == "transaction_derived":
                db.execute("UPDATE accounts SET current_balance=current_balance-? WHERE id=?", (original["amount"], original["account_id"]))
            first = cleaned[0]
            db.execute("UPDATE transactions SET transaction_date=?,description=?,category_id=?,amount=?,account_id=? WHERE id=?", (first[0], first[1], first[3], first[4], first[5]["id"] if first[5] else None, transaction_id))
            for transaction_date, description, category, category_id, amount, account in cleaned[1:]:
                db.execute("INSERT INTO transactions(transaction_date,posted_date,raw_description,description,category_id,amount,account_id,card_last4,source) VALUES(?,?,?,?,?,?,?,?,?)", (transaction_date, original["posted_date"], original["raw_description"], description, category_id, amount, account["id"] if account else None, original["card_last4"], f"split:{transaction_id}"))
            for transaction_date, description, category, category_id, amount, account in cleaned:
                db.execute("UPDATE funds SET balance=balance+? WHERE name=?", (amount, category))
                if account and account["tracking_mode"] == "transaction_derived":
                    db.execute("UPDATE accounts SET current_balance=current_balance+? WHERE id=?", (amount, account["id"]))
        json_response(self, {"created": len(cleaned)})

    def split_inbox_transaction(self, payload):
        try:
            transaction_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid Review Inbox transaction to split."}, 400)
        rows = payload.get("rows", [])
        if not isinstance(rows, list) or len(rows) < 2:
            return json_response(self, {"error": "A split needs at least two lines."}, 400)
        with connect() as db:
            original = db.execute("SELECT * FROM inbox_transactions WHERE id=?", (transaction_id,)).fetchone()
            if not original:
                return json_response(self, {"error": "That transaction is no longer in Review Inbox."}, 404)
            category_ids = {row["name"]: row["id"] for row in valid_category_rows(db)}
            account_ids = {row["name"]: row["id"] for row in db.execute("SELECT id,name FROM accounts WHERE active=1")}
            cleaned = []
            for row in rows:
                entered_date = (row.get("transactionDate") or "").strip()
                parsed_date = None
                for date_format in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
                    try:
                        parsed_date = datetime.strptime(entered_date, date_format).date().isoformat()
                        break
                    except ValueError:
                        continue
                description = (row.get("description") or "").strip()
                category = (row.get("category") or "").strip()
                account = (row.get("account") or "").strip()
                try:
                    amount = float(str(row.get("amount", "")).replace("$", "").replace(",", ""))
                except ValueError:
                    amount = math.nan
                if parsed_date is None or not description or category not in category_ids or account not in account_ids or not math.isfinite(amount):
                    return json_response(self, {"error": "Every split needs a valid date, description, category, account, and amount."}, 400)
                cleaned.append((parsed_date, description, category_ids[category], amount, account_ids[account]))
            if abs(sum(row[3] for row in cleaned) - original["amount"]) >= .005:
                return json_response(self, {"error": "The split amounts must add up to the original transaction amount."}, 400)
            db.execute("INSERT OR IGNORE INTO ignored_inbox_transactions(fingerprint) VALUES(?)", (original["fingerprint"],))
            db.execute("DELETE FROM inbox_transactions WHERE id=?", (transaction_id,))
            for index, (transaction_date, description, category_id, amount, account_id) in enumerate(cleaned, 1):
                child_fingerprint = hashlib.sha256(f"{original['fingerprint']}:review-split:{index}".encode()).hexdigest()
                db.execute("INSERT INTO inbox_transactions(fingerprint,transaction_date,posted_date,raw_description,description,category_id,amount,account_id,card_last4,source_account_id,source) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (child_fingerprint, transaction_date, original["posted_date"], original["raw_description"], description, category_id, amount, account_id, original["card_last4"], original["source_account_id"], original["source"]))
                db.execute("INSERT OR IGNORE INTO import_fingerprints(fingerprint) VALUES(?)", (child_fingerprint,))
        json_response(self, {"created": len(cleaned)})

    def delete_transaction(self, payload):
        transaction_id = payload.get("id")
        with connect() as db:
            old = db.execute("SELECT t.amount,c.name category,a.tracking_mode,a.id account_id FROM transactions t LEFT JOIN categories c ON c.id=t.category_id LEFT JOIN accounts a ON a.id=t.account_id WHERE t.id=?", (transaction_id,)).fetchone()
            if not old:
                return json_response(self, {"error": "Transaction not found."}, 404)
            db.execute("UPDATE duplicate_reviews SET matched_transaction_id=NULL,reason=reason||' (original match was deleted)' WHERE matched_transaction_id=?", (transaction_id,))
            db.execute("UPDATE duplicate_audit SET matched_transaction_id=NULL WHERE matched_transaction_id=?", (transaction_id,))
            db.execute("DELETE FROM transactions WHERE id=?", (transaction_id,))
            db.execute("UPDATE funds SET balance=balance-? WHERE name=?", (old["amount"], old["category"]))
            if old["tracking_mode"] == "transaction_derived":
                db.execute("UPDATE accounts SET current_balance=current_balance-? WHERE id=?", (old["amount"], old["account_id"]))
        json_response(self, {"deleted": 1})

    def save_accounts(self, payload):
        rows = payload.get("rows", [])
        with connect() as db:
            active = {r["id"]: dict(r) for r in db.execute("SELECT id,name FROM accounts WHERE active=1")}
            cleaned = []
            for row in rows:
                try:
                    account_id = int(row.get("id"))
                except (TypeError, ValueError):
                    return json_response(self, {"error": "An account could not be identified."}, 400)
                if account_id not in active:
                    return json_response(self, {"error": "The account list changed. Refresh and try again."}, 409)
                name = (row.get("name") or "").strip()
                if not name:
                    return json_response(self, {"error": "Every account needs a name."}, 400)
                duplicate = db.execute("SELECT id FROM accounts WHERE name=? COLLATE NOCASE AND id<>?", (name, account_id)).fetchone()
                if duplicate:
                    return json_response(self, {"error": f"An account named {name} already exists."}, 400)
                cleaned.append((row, account_id, name))
            if len({name.casefold() for _, _, name in cleaned}) != len(cleaned):
                return json_response(self, {"error": "Every account needs a different name."}, 400)
            for row, account_id, name in cleaned:
                db.execute("UPDATE accounts SET name=? WHERE id=?", (name, account_id))
                if row.get("updateMode") == "automatic":
                    mapped = db.execute("SELECT 1 FROM bank_account_mappings WHERE provider='plaid' AND active=1 AND ledger_account_id=? LIMIT 1", (account_id,)).fetchone()
                    db.execute("UPDATE accounts SET tracking_mode='plaid_balance',current_balance=CASE WHEN ? THEN current_balance ELSE 0 END WHERE id=?", (bool(mapped), account_id))
                    continue
                try:
                    balance = float(str(row.get("balance", "")).replace("$", "").replace(",", ""))
                except ValueError:
                    return json_response(self, {"error": "Enter a valid account balance."}, 400)
                if not math.isfinite(balance):
                    return json_response(self, {"error": "Enter a valid account balance."}, 400)
                db.execute("UPDATE accounts SET current_balance=?,tracking_mode='manual_monthly' WHERE id=?", (balance, account_id))
        json_response(self, {"saved": len(cleaned)})

    def create_account(self, payload):
        name = (payload.get("name") or "").strip()
        if not name:
            return json_response(self, {"error": "Enter an account name."}, 400)
        try:
            balance = float(str(payload.get("balance", "0")).replace("$", "").replace(",", ""))
        except ValueError:
            return json_response(self, {"error": "Enter a valid starting balance."}, 400)
        if not math.isfinite(balance):
            return json_response(self, {"error": "Enter a valid starting balance."}, 400)
        tracking_mode = "plaid_balance" if payload.get("updateMode") == "automatic" else "manual_monthly"
        with connect() as db:
            existing = db.execute("SELECT id,active FROM accounts WHERE name=? COLLATE NOCASE", (name,)).fetchone()
            if existing and existing["active"]:
                return json_response(self, {"error": "An account with that name already exists."}, 400)
            if existing:
                db.execute("UPDATE accounts SET name=?,current_balance=?,tracking_mode=?,active=1 WHERE id=?", (name, balance, tracking_mode, existing["id"]))
                account_id = existing["id"]
            else:
                next_order = db.execute("SELECT COALESCE(MAX(sort_order),-1)+1 FROM accounts WHERE active=1").fetchone()[0]
                account_id = db.execute("INSERT INTO accounts(name,current_balance,tracking_mode,active,sort_order) VALUES(?,?,?,1,?)", (name, balance, tracking_mode, next_order)).lastrowid
        json_response(self, {"created": True, "id": account_id, "name": name})

    def reorder_accounts(self, payload):
        ids = []
        for value in payload.get("ids", []):
            try:
                ids.append(int(value))
            except (TypeError, ValueError):
                continue
        if not ids or len(ids) != len(set(ids)):
            return json_response(self, {"error": "The account order was not valid."}, 400)
        with connect() as db:
            active_ids = {row["id"] for row in db.execute("SELECT id FROM accounts WHERE active=1")}
            if set(ids) != active_ids:
                return json_response(self, {"error": "The account list changed. Refresh and try again."}, 409)
            db.executemany("UPDATE accounts SET sort_order=? WHERE id=?", ((position, account_id) for position, account_id in enumerate(ids)))
        json_response(self, {"saved": len(ids)})

    def delete_account(self, payload):
        try:
            account_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid account."}, 400)
        with connect() as db:
            account = db.execute("SELECT id,name FROM accounts WHERE id=? AND active=1", (account_id,)).fetchone()
            if not account:
                return json_response(self, {"error": "That account is no longer available."}, 404)
            transaction_count = db.execute("SELECT COUNT(*) FROM transactions WHERE account_id=?", (account_id,)).fetchone()[0]
            inbox_count = db.execute("SELECT COUNT(*) FROM inbox_transactions WHERE account_id=?", (account_id,)).fetchone()[0]
            if inbox_count:
                return json_response(self, {"error": "Submit, reassign, or delete this account's Review Inbox transactions before deleting the account."}, 400)
            db.execute("UPDATE bank_account_mappings SET ledger_account_id=NULL WHERE ledger_account_id=?", (account_id,))
            if transaction_count or db.execute("SELECT 1 FROM balance_snapshots WHERE account_id=? LIMIT 1", (account_id,)).fetchone():
                db.execute("UPDATE accounts SET active=0 WHERE id=?", (account_id,))
                archived = True
            else:
                db.execute("DELETE FROM accounts WHERE id=?", (account_id,))
                archived = False
        json_response(self, {"deleted": True, "archived": archived, "name": account["name"]})

    def save_inbox(self, payload):
        rows = payload.get("rows", [])
        with connect() as db:
            category_ids = {r["name"]: r["id"] for r in valid_category_rows(db)}
            account_ids = {r["name"]: r["id"] for r in db.execute("SELECT id,name FROM accounts WHERE active=1")}
            cleaned = []
            for r in rows:
                category = r.get("category", "")
                account = r.get("account", "")
                if category and category not in category_ids:
                    return json_response(self, {"error": f"{category} is not a valid category for this budget."}, 400)
                if account not in account_ids:
                    return json_response(self, {"error": "Every Review Inbox transaction needs a valid account."}, 400)
                entered_date = (r.get("transactionDate") or "").strip()
                parsed_date = None
                for date_format in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
                    try:
                        parsed_date = datetime.strptime(entered_date, date_format).date().isoformat()
                        break
                    except ValueError:
                        continue
                if parsed_date is None:
                    return json_response(self, {"error": "Every Review Inbox transaction needs a valid date."}, 400)
                cleaned.append(((r.get("description") or "").strip(), category_ids.get(category), account_ids.get(account), parsed_date, r["id"]))
            db.executemany("UPDATE inbox_transactions SET description=?,category_id=?,account_id=?,transaction_date=? WHERE id=?", cleaned)
        json_response(self, {"saved": len(rows)})

    def delete_inbox_transaction(self, payload):
        try:
            transaction_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid Review Inbox transaction."}, 400)
        with connect() as db:
            row = db.execute("SELECT fingerprint FROM inbox_transactions WHERE id=?", (transaction_id,)).fetchone()
            if not row:
                return json_response(self, {"error": "That transaction is no longer in Review Inbox."}, 404)
            db.execute("INSERT OR IGNORE INTO ignored_inbox_transactions(fingerprint) VALUES(?)", (row["fingerprint"],))
            db.execute("DELETE FROM inbox_transactions WHERE id=?", (transaction_id,))
        json_response(self, {"deleted": True})

    def delete_inbox_transactions(self, payload):
        ids = []
        for value in payload.get("ids", []):
            try:
                ids.append(int(value))
            except (TypeError, ValueError):
                continue
        ids = list(dict.fromkeys(ids))
        if not ids:
            return json_response(self, {"error": "Select at least one Review Inbox transaction."}, 400)
        placeholders = ",".join("?" for _ in ids)
        with connect() as db:
            rows = list(db.execute(f"SELECT id,fingerprint FROM inbox_transactions WHERE id IN ({placeholders})", tuple(ids)))
            if not rows:
                return json_response(self, {"error": "The selected transactions are no longer in Review Inbox."}, 404)
            db.executemany("INSERT OR IGNORE INTO ignored_inbox_transactions(fingerprint) VALUES(?)", ((row["fingerprint"],) for row in rows))
            db.execute(f"DELETE FROM inbox_transactions WHERE id IN ({placeholders})", tuple(ids))
        json_response(self, {"deleted": len(rows)})

    def report_inbox_duplicate(self, payload):
        try:
            transaction_id = int(payload.get("id"))
        except (TypeError, ValueError):
            return json_response(self, {"error": "Choose a valid Review Inbox transaction."}, 400)
        with connect() as db:
            row = db.execute("SELECT i.*,a.name account_name,c.name category_name FROM inbox_transactions i LEFT JOIN accounts a ON a.id=i.account_id LEFT JOIN categories c ON c.id=i.category_id WHERE i.id=?", (transaction_id,)).fetchone()
            if not row:
                return json_response(self, {"error": "That transaction is no longer in Review Inbox."}, 404)
            installation = db.execute("SELECT value FROM metadata WHERE key='diagnostic_installation_id'").fetchone()
            installation_id = installation["value"] if installation else uuid.uuid4().hex
            if not installation:
                db.execute("INSERT INTO metadata(key,value) VALUES('diagnostic_installation_id',?)", (installation_id,))
            candidates = [dict(item) for item in db.execute("SELECT t.id,t.transaction_date transactionDate,t.posted_date postedDate,COALESCE(t.raw_description,t.description) description,t.amount,a.name account,t.source,t.source_fingerprint sourceFingerprint FROM transactions t LEFT JOIN accounts a ON a.id=t.account_id WHERE t.account_id IS ? AND ABS(t.amount-?)<0.005 AND t.transaction_date BETWEEN date(?,'-14 days') AND date(?,'+14 days') ORDER BY ABS(julianday(t.transaction_date)-julianday(?)),t.id DESC LIMIT 10", (row["account_id"], row["amount"], row["transaction_date"], row["transaction_date"], row["transaction_date"]))]
            audit = [dict(item) for item in db.execute("SELECT decision,reason,repeat_count,created_at createdAt,last_seen_at lastSeenAt FROM duplicate_audit WHERE fingerprint=? ORDER BY id DESC LIMIT 10", (row["fingerprint"],))]
            pending = [dict(item) for item in db.execute("SELECT transaction_date transactionDate,description,amount,source,provider_transaction_id providerId FROM plaid_pending_transactions WHERE provider_account_id=? AND ABS(amount-?)<0.005 AND transaction_date BETWEEN date(?,'-14 days') AND date(?,'+14 days') ORDER BY updated_at DESC LIMIT 10", (row["source_account_id"], row["amount"], row["transaction_date"], row["transaction_date"]))] if row["source_account_id"] else []

        def short_hash(value):
            return hashlib.sha256(str(value).encode()).hexdigest()[:20] if value else None

        for candidate in candidates:
            candidate["sourceFingerprint"] = short_hash(candidate["sourceFingerprint"])
        for item in pending:
            item["providerIdHash"] = short_hash(item.pop("providerId", None))
        report_data = {
            "reportedAt": datetime.now().isoformat(timespec="seconds"),
            "inbox": {"fingerprint": short_hash(row["fingerprint"]), "transactionDate": row["transaction_date"], "postedDate": row["posted_date"], "rawDescription": row["raw_description"], "enteredDescription": row["description"], "category": row["category_name"], "amount": row["amount"], "account": row["account_name"], "source": row["source"], "sourceAccountHash": short_hash(row["source_account_id"]), "importedAt": row["imported_at"]},
            "possibleLedgerMatches": candidates,
            "previousDecisions": audit,
            "relatedPendingTransactions": pending,
        }
        state = ensure_profile_state()
        profile = next((item for item in state.get("profiles", []) if item["id"] == ACTIVE_PROFILE_ID), {"name": ACTIVE_PROFILE_ID})
        outgoing = json.dumps({"appVersion": APP_VERSION, "installationId": installation_id, "budgetName": profile["name"], "summary": f"Possible duplicate: {row['raw_description']} on {row['transaction_date']} for {row['amount']:.2f}", "reportData": report_data}).encode()
        try:
            request = urllib.request.Request(DIAGNOSTIC_REPORT_URL, data=outgoing, headers={"Content-Type": "application/json", "User-Agent": f"Home-Ledger/{APP_VERSION}"}, method="POST")
            with urllib.request.urlopen(request, timeout=15) as response:
                result = json.loads(response.read())
            report_id = result.get("reportId")
            if not report_id:
                raise ValueError("The reporting service did not return a report number.")
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError, json.JSONDecodeError) as error:
            return json_response(self, {"error": f"The duplicate report could not be sent. The transaction was left in Review Inbox. {error}"}, 502)
        with connect() as db:
            current = db.execute("SELECT fingerprint FROM inbox_transactions WHERE id=?", (transaction_id,)).fetchone()
            if not current or current["fingerprint"] != row["fingerprint"]:
                return json_response(self, {"error": "The report was sent, but the transaction changed before it could be removed.", "reportId": report_id}, 409)
            db.execute("INSERT OR IGNORE INTO ignored_inbox_transactions(fingerprint) VALUES(?)", (row["fingerprint"],))
            db.execute("DELETE FROM inbox_transactions WHERE id=?", (transaction_id,))
            record_decision(db, row["fingerprint"], "user_reported_duplicate", f"User reported duplicate as {report_id}")
        json_response(self, {"reported": True, "reportId": report_id})

    def submit_inbox(self, payload):
        ids = [int(value) for value in payload.get("ids", []) if str(value).isdigit()]
        if not ids:
            return json_response(self, {"error": "No completed transactions were selected."}, 400)
        placeholders = ",".join("?" for _ in ids)
        with connect() as db:
            selected = tuple(ids)
            selected_rows = list(db.execute(f"SELECT id,transaction_date,description,category_id,account_id FROM inbox_transactions WHERE id IN ({placeholders})", selected))
            count = len(selected_rows)
            valid_categories = {row["id"] for row in valid_category_rows(db)}
            valid_accounts = {row["id"] for row in db.execute("SELECT id FROM accounts WHERE active=1")}
            invalid = False
            for row in selected_rows:
                try:
                    datetime.strptime(row["transaction_date"], "%Y-%m-%d")
                except (TypeError, ValueError):
                    invalid = True
                if not row["description"].strip() or row["category_id"] not in valid_categories or row["account_id"] not in valid_accounts:
                    invalid = True
            if count != len(set(ids)) or invalid:
                return json_response(self, {"error": "One or more selected transactions has an invalid date, category, or account."}, 400)
            adjustments = list(db.execute(f"SELECT account_id,SUM(amount) amount FROM inbox_transactions WHERE id IN ({placeholders}) GROUP BY account_id", selected))
            fund_adjustments = list(db.execute(f"SELECT c.name,SUM(i.amount) amount FROM inbox_transactions i JOIN categories c ON c.id=i.category_id JOIN funds f ON f.name=c.name WHERE i.id IN ({placeholders}) GROUP BY c.name", selected))
            db.execute(f"INSERT INTO transactions(transaction_date,posted_date,raw_description,description,category_id,amount,account_id,card_last4,source,source_fingerprint) SELECT transaction_date,posted_date,raw_description,description,category_id,amount,account_id,card_last4,source,fingerprint FROM inbox_transactions WHERE id IN ({placeholders})", selected)
            for adjustment in adjustments:
                db.execute("UPDATE accounts SET current_balance=current_balance+? WHERE id=? AND tracking_mode='transaction_derived'", (adjustment["amount"], adjustment["account_id"]))
            for adjustment in fund_adjustments:
                db.execute("UPDATE funds SET balance=balance+? WHERE name=?", (adjustment["amount"], adjustment["name"]))
            db.execute(f"DELETE FROM inbox_transactions WHERE id IN ({placeholders})", selected)
        json_response(self, {"submitted": count})


class HomeLedgerHTTPServer(ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        error = sys.exc_info()[1]
        if isinstance(error, (BrokenPipeError, ConnectionAbortedError, ConnectionResetError)):
            return
        super().handle_error(request, client_address)


if __name__ == "__main__":
    initial_profiles = ensure_profile_state()
    activate_profile(initial_profiles.get("active", "home-ledger"))
    create_daily_backup()
    initialize(blank=ACTIVE_PROFILE_ID != "home-ledger" and not DB_PATH.exists())
    run_monthly_rollover()
    server = HomeLedgerHTTPServer((HOST, PORT), Handler)
    if os.environ.get("HOME_LEDGER_NO_BROWSER") != "1":
        def open_home_ledger():
            url = f"http://{HOST}:{PORT}"
            chrome_locations = [
                Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
                Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
                Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
            ]
            chrome = next((path for path in chrome_locations if path.exists()), None)
            if chrome:
                subprocess.Popen([str(chrome), url])
            else:
                webbrowser.open(url)
        threading.Timer(0.7, open_home_ledger).start()
    print(f"Home Ledger is running at http://{HOST}:{PORT}")
    print("Close this window to stop the app.")
    server.serve_forever()
