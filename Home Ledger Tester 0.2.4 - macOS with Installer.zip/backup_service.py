import shutil
import sqlite3
from datetime import datetime


def sqlite_backup(source, destination):
    source_db = sqlite3.connect(source)
    backup_db = sqlite3.connect(destination)
    try:
        source_db.backup(backup_db)
    finally:
        backup_db.close()
        source_db.close()


def create_complete_daily_backup(data_root, app_root, backup_dir, profiles, data_files, app_files):
    destination = backup_dir / ("daily_" + datetime.now().strftime("%Y-%m-%d"))
    marker = destination / "complete-backup.txt"
    if marker.exists():
        return destination
    destination.mkdir(parents=True, exist_ok=True)
    resolved_data_root = data_root.resolve()
    for profile in profiles:
        source = (data_root / profile.get("database", "")).resolve()
        if source.exists() and (resolved_data_root in source.parents or source == resolved_data_root):
            sqlite_backup(source, destination / source.name)
    for root, filenames in ((data_root, data_files), (app_root, app_files)):
        for filename in filenames:
            source = root / filename
            if source.exists():
                shutil.copy2(source, destination / filename)
    marker.write_text(datetime.now().isoformat(timespec="seconds"), encoding="utf-8")
    return destination
