#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display dialog "Home Ledger Tester needs Python 3. Download and install it, then open this file again." buttons {"Open Python Download"} default button 1 with icon caution'
  open "https://www.python.org/downloads/macos/"
  exit 1
fi
python3 server.py
