#!/bin/bash
set -e

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$HOME/Applications/Home Ledger Tester"
DATA_DIR="$HOME/Library/Application Support/Home Ledger Tester"
DESKTOP_LAUNCHER="$HOME/Desktop/Home Ledger Tester.command"

show_message() {
  osascript -e "display dialog \"$1\" buttons {\"OK\"} default button 1" >/dev/null
}

if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display dialog "Home Ledger Tester needs Python 3. Install Python, then run this installer again." buttons {"Open Python Download"} default button 1 with icon caution' >/dev/null
  open "https://www.python.org/downloads/macos/"
  exit 1
fi

mkdir -p "$APP_DIR" "$DATA_DIR"
for FILE in server.py backup_service.py duplicate_rules.py duplicate_service.py index.html polish.css recurring.js all-transactions-account.js tester-edition.js app-update.js VERSION.txt "TESTER GUIDE.txt"; do
  cp "$SOURCE_DIR/$FILE" "$APP_DIR/$FILE"
done

cat > "$APP_DIR/Open Home Ledger Tester.command" <<'LAUNCHER'
#!/bin/bash
cd "$HOME/Applications/Home Ledger Tester"
exec python3 server.py
LAUNCHER
chmod +x "$APP_DIR/Open Home Ledger Tester.command"
cp "$APP_DIR/Open Home Ledger Tester.command" "$DESKTOP_LAUNCHER"
chmod +x "$DESKTOP_LAUNCHER"

show_message "Home Ledger Tester was installed. A Home Ledger Tester launcher was added to your Desktop. Your budgets and Plaid information will remain separate from future app updates."
open "$DESKTOP_LAUNCHER"
