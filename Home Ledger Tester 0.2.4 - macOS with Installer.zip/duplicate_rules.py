import re
from datetime import datetime
from difflib import SequenceMatcher


def normalized_merchant(value):
    value = re.sub(r"[^A-Z0-9 ]", " ", (value or "").upper())
    ignored = {"THE", "INC", "LLC", "ONLINE", "PURCHASE", "PAYMENT", "DEBIT", "CREDIT", "CARD"}
    return " ".join(part for part in value.split() if part not in ignored)


def merchant_similarity(left, right):
    left = normalized_merchant(left)
    right = normalized_merchant(right)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    if left in right or right in left:
        return 0.92
    return SequenceMatcher(None, left, right).ratio()


def legacy_duplicate_candidates(db, account_id, amount, transaction_date, posted_date, description):
    """Return plausible legacy/manual matches; never decides that a Plaid transaction is a duplicate."""
    dates = [value for value in (transaction_date, posted_date) if value]
    if not dates:
        return []
    incoming_dates = [datetime.strptime(value, "%Y-%m-%d").date() for value in dates]
    rows = db.execute(
        """
        SELECT id,transaction_date,posted_date,raw_description,description,amount,source
        FROM transactions
        WHERE account_id=?
          AND source NOT IN ('plaid_production','plaid_sandbox')
          AND ABS(amount-?)<0.005
          AND COALESCE(posted_date,transaction_date)>=date(?,'-7 day')
          AND transaction_date<=date(?,'+7 day')
        """,
        (account_id, amount, min(dates), max(dates)),
    )
    matches = []
    for row in rows:
        existing_dates = [datetime.strptime(value, "%Y-%m-%d").date() for value in (row["transaction_date"], row["posted_date"]) if value]
        distance = min(abs((left - right).days) for left in incoming_dates for right in existing_dates)
        similarity = merchant_similarity(description, row["raw_description"] or row["description"])
        if distance <= 2 and similarity >= 0.82:
            matches.append({
                "transaction_id": row["id"],
                "date_distance": distance,
                "merchant_similarity": round(similarity, 3),
                "reason": f"Same amount, merchant similarity {round(similarity * 100)}%, dates {distance} day{'s' if distance != 1 else ''} apart",
            })
    return matches
