(() => {
  const VERSION = '0.2.4';
  document.title = `Home Ledger Tester ${VERSION}`;
  const brand = document.querySelector('.brand');
  if (brand?.firstChild) brand.firstChild.nodeValue = 'Home Ledger Tester';
  const local = document.querySelector('.local');
  if (local) local.insertAdjacentHTML('beforeend', `<br><br><b>Tester version ${VERSION}</b>`);

  const originalRenderAllForTester = renderAll;
  renderAll = function() {
    originalRenderAllForTester();
    renderAccounts();
  };

  const actions = document.querySelector('header .actions');
  const sync = document.createElement('button');
  sync.id = 'testerSyncPlaid';
  sync.className = 'button';
  sync.type = 'button';
  sync.textContent = 'Sync bank transactions';
  sync.onclick = () => runPlaidSync(true);
  actions?.appendChild(sync);
  document.querySelectorAll('nav button').forEach(button => button.addEventListener('click', () => {
    sync.classList.toggle('hidden', button.dataset.view !== 'inbox');
  }));

})();
