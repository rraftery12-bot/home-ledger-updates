@echo off
title Home Ledger Tester
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 server.py
  goto :end
)
where python >nul 2>&1
if not errorlevel 1 (
  python server.py
  goto :end
)
echo Python 3 is required to run Home Ledger Tester.
echo Download it from https://www.python.org/downloads/windows/
start "" "https://www.python.org/downloads/windows/"
pause
:end
