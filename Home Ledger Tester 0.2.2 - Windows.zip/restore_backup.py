from __future__ import annotations

import shutil
import socket
import sqlite3
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BACKUPS = ROOT / "backups"
DATABASE = ROOT / "home_ledger.sqlite3"
APP_FILES = ("server.py", "index.html", "README.txt", "Start Home Ledger.bat")


def app_is_running():
    with socket.socket() as connection:
        connection.settimeout(0.25)
        return connection.connect_ex(("127.0.0.1", 8765)) == 0


def copy_database(source: Path, destination: Path):
    source_db = sqlite3.connect(source)
    destination_db = sqlite3.connect(destination)
    try:
        source_db.backup(destination_db)
    finally:
        destination_db.close()
        source_db.close()


def main():
    if app_is_running():
        print("Close the Home Ledger window before restoring a backup, then try again.")
        return
    choices = sorted((folder for folder in BACKUPS.glob("*") if (folder / DATABASE.name).exists()), reverse=True)
    if not choices:
        print("No Home Ledger backups were found.")
        return
    print("Available Home Ledger backups:\n")
    for number, folder in enumerate(choices, 1):
        print(f"  {number}. {folder.name}")
    answer = input("\nEnter the backup number to restore, or press Enter to cancel: ").strip()
    if not answer.isdigit() or not 1 <= int(answer) <= len(choices):
        print("Restore cancelled.")
        return
    selected = choices[int(answer) - 1]
    if input(f'Type RESTORE to replace the current app with "{selected.name}": ').strip() != "RESTORE":
        print("Restore cancelled.")
        return

    safety = BACKUPS / ("before_restore_" + datetime.now().strftime("%Y-%m-%d_%H%M%S"))
    safety.mkdir(parents=True, exist_ok=False)
    copy_database(DATABASE, safety / DATABASE.name)
    for filename in APP_FILES:
        source = ROOT / filename
        if source.exists():
            shutil.copy2(source, safety / filename)

    copy_database(selected / DATABASE.name, DATABASE)
    for filename in APP_FILES:
        source = selected / filename
        if source.exists():
            shutil.copy2(source, ROOT / filename)
    print("\nRestore complete. Double-click Start Home Ledger.bat to reopen the app.")
    print(f"A safety copy of the replaced version was saved as {safety.name}.")


if __name__ == "__main__":
    main()
