(() => {
  const VERSION = '0.2.0';
  document.title = `Home Ledger Tester ${VERSION}`;
  const brand = document.querySelector('.brand');
  if (brand?.firstChild) brand.firstChild.nodeValue = 'Home Ledger Tester';
  const local = document.querySelector('.local');
  if (local) local.insertAdjacentHTML('beforeend', `<br><br><b>Tester version ${VERSION}</b>`);

  const originalRenderAllForTester = renderAll;
  renderAll = function() {
    originalRenderAllForTester();
    renderAccounts();
  };

  const actions = document.querySelector('header .actions');
  const csv = document.querySelector('#importLabel');
  if (csv?.firstChild) csv.firstChild.nodeValue = 'Import CSV (optional)';
  const sync = document.createElement('button');
  sync.id = 'testerSyncPlaid';
  sync.className = 'button';
  sync.type = 'button';
  sync.textContent = 'Sync bank transactions';
  sync.onclick = () => runPlaidSync(true);
  actions?.insertBefore(sync, csv || null);
  document.querySelectorAll('nav button').forEach(button => button.addEventListener('click', () => {
    sync.classList.toggle('hidden', button.dataset.view !== 'inbox');
  }));

})();
