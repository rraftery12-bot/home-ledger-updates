(() => {
  const VERSION = '0.2.2';
  const settingsLayout = document.querySelector('#settings .bankLayout');
  if (!settingsLayout || document.querySelector('#checkForUpdates')) return;
  const card = document.createElement('div');
  card.className = 'bankCard';
  card.innerHTML = `<h2>Application updates</h2><p>Check for a verified Home Ledger update without replacing your budgets or Plaid connections.</p><div class="bankStatus"><div><span>Installed version</span><b id="installedVersion">${VERSION}</b></div><div><span>Update status</span><b id="updateStatus">Not checked</b></div></div><div class="bankActions" style="margin-top:20px"><button class="button" id="checkForUpdates" type="button">Check for updates</button><button class="button hidden" id="installUpdate" type="button">Install update</button></div><details style="margin-top:18px"><summary>Update source</summary><div class="bankFields"><label>Secure update information URL<input id="updateManifestUrl" type="url" autocomplete="off" placeholder="https://..."></label></div><button class="button" id="saveUpdateSource" type="button">Save update source</button></details><p class="privacyNote">Before installation, Home Ledger verifies the package and saves a recovery copy of the current program. Financial data is not included in an update.</p>`;
  settingsLayout.appendChild(card);
  let availableUpdate = null;
  async function checkForUpdates() {
    const status = document.querySelector('#updateStatus'), check = document.querySelector('#checkForUpdates'), install = document.querySelector('#installUpdate');
    check.disabled = true; status.textContent = 'Checking…';
    try {
      const result = await api('/api/update/status');
      document.querySelector('#installedVersion').textContent = result.currentVersion;
      document.querySelector('#updateManifestUrl').value = result.manifestUrl || '';
      if (!result.configured) { status.textContent = 'Update source not configured'; install.classList.add('hidden'); }
      else if (result.available) { availableUpdate = result; status.textContent = `Version ${result.version} is available`; install.classList.remove('hidden'); }
      else { availableUpdate = null; status.textContent = 'Up to date'; install.classList.add('hidden'); }
    } catch (error) { status.textContent = 'Check failed'; alert(error.message); }
    finally { check.disabled = false; }
  }
  document.querySelector('#checkForUpdates').onclick = checkForUpdates;
  document.querySelector('#saveUpdateSource').onclick = async () => {
    try { await api('/api/update/settings', {method:'POST', body:JSON.stringify({manifestUrl:document.querySelector('#updateManifestUrl').value.trim()})}); await checkForUpdates(); }
    catch (error) { alert(error.message); }
  };
  document.querySelector('#installUpdate').onclick = async () => {
    if (!availableUpdate || !confirm(`Install Home Ledger Tester ${availableUpdate.version}? The app will save a recovery copy and restart.`)) return;
    const install = document.querySelector('#installUpdate'); install.disabled = true;
    document.querySelector('#updateStatus').textContent = 'Downloading and installing…';
    try {
      const result = await api('/api/update/install', {method:'POST', body:'{}'});
      document.querySelector('#updateStatus').textContent = `Version ${result.version} installed · restarting…`;
      setTimeout(() => location.reload(), 3500);
    } catch (error) { install.disabled = false; document.querySelector('#updateStatus').textContent = 'Installation failed'; alert(error.message); }
  };
  document.querySelector('nav button[data-view="settings"]')?.addEventListener('click', checkForUpdates);
})();
