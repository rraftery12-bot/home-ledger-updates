(() => {
  const style = document.createElement('style');
  style.textContent = `.recurringCard{width:min(760px,100%);max-height:90vh;overflow:auto}.recurringForm{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px;margin:18px 0}.recurringForm label{display:grid;gap:6px;font-weight:700}.recurringForm input,.recurringForm select{width:100%;border:1px solid #d2d6cf;border-radius:7px;padding:9px;background:#fff;color:var(--ink)}.recurringForm .wide{grid-column:1/-1}.recurringActions{display:flex;justify-content:flex-end;gap:9px;margin-top:14px}.recurringList{display:grid;gap:8px;margin-top:12px}.recurringRow{display:grid;grid-template-columns:minmax(150px,1fr) auto auto;gap:14px;align-items:center;border:1px solid var(--line);border-radius:9px;padding:12px;background:#fafaf7}.recurringRow small{display:block;color:var(--muted);margin-top:4px}.recurringEmpty{color:var(--muted);padding:14px 0}@media(max-width:650px){.recurringForm{grid-template-columns:1fr}.recurringForm .wide{grid-column:auto}.recurringRow{grid-template-columns:1fr auto}}`;
  document.head.appendChild(style);

  const button = document.createElement('button');
  button.className = 'button';
  button.id = 'openRecurring';
  button.type = 'button';
  button.textContent = '↻ Recurring transactions';
  document.querySelector('#addTransaction')?.insertAdjacentElement('afterend', button);

  const modal = document.createElement('div');
  modal.id = 'recurringModal';
  modal.className = 'choiceModal hidden';
  modal.innerHTML = `<div class="choiceCard recurringCard"><h2>Recurring transactions</h2><p>Create transactions automatically on a schedule. Transactions already created remain in All Transactions if you stop a schedule.</p><form id="recurringForm" class="recurringForm"><label class="wide">Description<input id="recurringDescription" required></label><label>First transaction date<input id="recurringDate" type="date" required></label><label>Repeat<select id="recurringFrequency"><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="biweekly">Every two weeks</option><option value="monthly" selected>Monthly</option><option value="quarterly">Quarterly</option><option value="yearly">Yearly</option></select></label><label>Category<select id="recurringCategory" required></select></label><label>Account<select id="recurringAccount" required></select></label><label>Amount<input id="recurringAmount" inputmode="decimal" placeholder="Use a minus sign for spending" required></label><div class="recurringActions wide"><button class="button" id="closeRecurring" type="button">Close</button><button class="button" id="saveRecurring" type="submit">Create schedule</button></div></form><h3>Active schedules</h3><div id="recurringList" class="recurringList"></div></div>`;
  document.body.appendChild(modal);
  document.querySelector('#recurringAccount').removeAttribute('required');
  document.querySelector('#recurringForm').setAttribute('autocomplete', 'off');
  document.querySelectorAll('#recurringForm input').forEach(input => {
    input.setAttribute('autocomplete', 'off');
    input.setAttribute('autocorrect', 'off');
  });

  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const frequencyLabels = {daily:'Daily',weekly:'Weekly',biweekly:'Every two weeks',monthly:'Monthly',quarterly:'Quarterly',yearly:'Yearly'};
  let editingId = null;
  function resetRecurringForm() {
    const today = new Date();
    editingId = null;
    document.querySelector('#recurringDescription').value = '';
    document.querySelector('#recurringAmount').value = '';
    document.querySelector('#recurringFrequency').value = 'monthly';
    document.querySelector('#recurringCategory').value = '';
    document.querySelector('#recurringAccount').value = '';
    document.querySelector('#recurringDate').type = 'text';
    document.querySelector('#recurringDate').placeholder = 'MM/DD/YYYY';
    document.querySelector('#recurringDate').value = `${today.getMonth()+1}/${today.getDate()}/${today.getFullYear()}`;
    document.querySelector('#saveRecurring').textContent = 'Create schedule';
  }
  const close = () => { resetRecurringForm(); modal.classList.add('hidden'); };
  const formatInputDate = value => { const [year, month, day] = value.split('-'); return `${Number(month)}/${Number(day)}/${year}`; };
  async function refreshList() {
    const result = await api('/api/recurring');
    document.querySelector('#recurringList').innerHTML = result.rows.length ? result.rows.map(row => `<div class="recurringRow"><div><b>${escapeHtml(row.description)}</b><small>${frequencyLabels[row.frequency]} · Next: ${displayLedgerDate(row.nextDate)} · ${escapeHtml(row.category)} · ${escapeHtml(row.account)}</small></div><b>${money(row.amount)}</b><span><button class="button editRecurring" data-id="${row.id}" type="button">Edit</button> <button class="deleteTransaction stopRecurring" data-id="${row.id}" data-description="${escapeHtml(row.description)}" type="button">Stop</button></span></div>`).join('') : '<div class="recurringEmpty">No active recurring transactions.</div>';
    document.querySelectorAll('.editRecurring').forEach(edit => edit.onclick = () => {
      const row = result.rows.find(item => item.id === Number(edit.dataset.id));
      editingId = row.id;
      document.querySelector('#recurringDescription').value = row.description;
      document.querySelector('#recurringDate').value = formatInputDate(row.startDate);
      document.querySelector('#recurringFrequency').value = row.frequency;
      document.querySelector('#recurringCategory').value = row.category;
      document.querySelector('#recurringAccount').value = row.account || '';
      document.querySelector('#recurringAmount').value = row.amount;
      document.querySelector('#saveRecurring').textContent = 'Save changes';
      document.querySelector('#recurringDescription').focus();
    });
    document.querySelectorAll('.stopRecurring').forEach(stop => stop.onclick = async () => {
      if (!confirm(`Stop the recurring transaction “${stop.dataset.description}”? Transactions already created will remain.`)) return;
      try { await api('/api/recurring/delete', {method:'POST', body:JSON.stringify({id:Number(stop.dataset.id)})}); await refreshList(); }
      catch (error) { alert(error.message); }
    });
  }
  button.onclick = async () => {
    document.querySelector('#recurringCategory').innerHTML = '<option value="">Select category</option>' + boot.categories.map(name => `<option>${escapeHtml(name)}</option>`).join('');
    document.querySelector('#recurringAccount').innerHTML = '<option value="">No account (internal transfer)</option>' + boot.accounts.map(account => `<option>${escapeHtml(account.name)}</option>`).join('');
    resetRecurringForm();
    modal.classList.remove('hidden');
    try { await refreshList(); document.querySelector('#recurringDescription').focus(); }
    catch (error) { alert(error.message); }
  };
  document.querySelector('#closeRecurring').onclick = close;
  modal.onclick = event => { if (event.target === modal) close(); };
  document.querySelector('#recurringForm').onsubmit = async event => {
    event.preventDefault();
    const amount = document.querySelector('#recurringAmount').value.trim();
    const payload = {id:editingId,description:document.querySelector('#recurringDescription').value.trim(),startDate:document.querySelector('#recurringDate').value,frequency:document.querySelector('#recurringFrequency').value,category:document.querySelector('#recurringCategory').value,account:document.querySelector('#recurringAccount').value,amount};
    const save = document.querySelector('#saveRecurring');
    try {
      save.disabled = true; save.textContent = 'Creating…';
      await api(editingId ? '/api/recurring/update' : '/api/recurring/create', {method:'POST', body:JSON.stringify(payload)});
      await load(boot.month); await loadLedger(1); await refreshList();
      resetRecurringForm();
      document.querySelector('#recurringDescription').focus();
    } catch (error) { alert(error.message); }
    finally { save.disabled = false; save.textContent = 'Create schedule'; }
  };
})();
