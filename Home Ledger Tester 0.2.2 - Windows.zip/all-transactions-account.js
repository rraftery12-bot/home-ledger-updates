(() => {
  const addBlankAccountChoice = () => {
    document.querySelectorAll('#ledgerRows select.accountSelect').forEach(select => {
      if (select.querySelector('option[value=""]')) return;
      const blank = document.createElement('option');
      blank.value = '';
      blank.textContent = '';
      select.insertBefore(blank, select.firstChild);
    });
  };
  const rows = document.querySelector('#ledgerRows');
  if (rows) new MutationObserver(addBlankAccountChoice).observe(rows, {childList:true, subtree:true});
  addBlankAccountChoice();
  const addTransaction = document.querySelector('#addTransaction');
  if (addTransaction) addTransaction.onclick = () => {
    const row = {id:`new-${Date.now()}`,isNew:true,transactionDate:'',description:'',category:'',amount:'',account:''};
    ledger.rows.unshift(row);
    ledger.total++;
    ledgerDirty.set(row.id,row);
    renderLedger();
    document.querySelector('#transactions .tablewrap').scrollTop = 0;
    setTimeout(() => document.querySelector('#ledgerRows tr:first-child .ledgerDescription')?.focus(), 0);
  };
})();
